import Vue from 'vue';
import './mocks/cryptoMock';
import './mocks/mutationObserverMock';

Vue.config.productionTip = false;
