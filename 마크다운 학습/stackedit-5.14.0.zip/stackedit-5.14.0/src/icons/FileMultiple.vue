<template>
  <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="-2 -2 26 26">
    <path d="M15,7H20.5L15,1.5V7M8,0H16L22,6V18C22,19.1 21.1,20 20,20H8C6.89,20 6,19.1 6,18V2C6,0.9 6.9,0 8,0M4,4V22H20V24H4C2.9,24 2,23.1 2,22V4H4Z" />
  </svg>
</template>
