import '../../../libs/clunderscore';
import cledit from './cleditCore';
import './cleditHighlighter';
import './cleditKeystroke';
import './cleditMarker';
import './cleditSelectionMgr';
import './cleditUndoMgr';
import './cleditUtils';
import './cleditWatcher';

export default cledit;
