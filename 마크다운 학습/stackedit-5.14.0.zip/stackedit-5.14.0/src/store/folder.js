import moduleTemplate from './moduleTemplate';
import empty from '../data/empties/emptyFolder';

const module = moduleTemplate(empty);

export default module;
