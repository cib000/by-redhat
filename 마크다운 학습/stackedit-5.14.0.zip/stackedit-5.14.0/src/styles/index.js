import 'katex/dist/katex.css';
import './fonts.scss';
import './prism.scss';
import './mermaid.scss';
import './base.scss';
