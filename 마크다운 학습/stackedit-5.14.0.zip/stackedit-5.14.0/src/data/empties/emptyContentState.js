export default (id = null) => ({
  id,
  type: 'contentState',
  selectionStart: 0,
  selectionEnd: 0,
  scrollPosition: null,
  hash: 0,
});
