export default (id = null) => ({
  id,
  type: 'folder',
  name: '',
  parentId: null,
  hash: 0,
});
