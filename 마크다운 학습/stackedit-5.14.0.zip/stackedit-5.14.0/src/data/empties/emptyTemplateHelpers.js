/* Add your custom Handlebars helpers here.

For example:

Handlebars.registerHelper('transform', function (options) {
  var result = options.fn(this);
  return new Handlebars.SafeString(
    result.replace(/<pre[^>]*>/g, '<pre class="prettyprint">')
  );
});

Then use the helper in your template:

{{#transform}}{{{files.0.content.html}}}{{/transform}}
*/

