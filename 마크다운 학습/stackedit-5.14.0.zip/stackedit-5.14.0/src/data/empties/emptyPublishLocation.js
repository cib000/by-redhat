export default (id = null) => ({
  id,
  type: 'publishLocation',
  providerId: null,
  fileId: null,
  templateId: null,
  hash: 0,
});
