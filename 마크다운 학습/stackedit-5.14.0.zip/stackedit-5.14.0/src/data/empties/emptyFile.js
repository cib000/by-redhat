export default (id = null) => ({
  id,
  type: 'file',
  name: '',
  parentId: null,
  hash: 0,
});
