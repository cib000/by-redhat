export default () => ({
  main: {
    id: 'main',
    name: 'Main workspace',
    // The rest will be filled by the workspace/workspacesById getter
  },
});
