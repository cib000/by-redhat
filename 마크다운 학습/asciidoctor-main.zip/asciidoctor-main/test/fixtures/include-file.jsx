const element = (
  <div>
    <h1>Hello, Programmer!</h1>
    <!-- tag::snippet[] -->
    <p>Welcome to the club.</p>
    <!-- end::snippet[] -->
  </div>
)
