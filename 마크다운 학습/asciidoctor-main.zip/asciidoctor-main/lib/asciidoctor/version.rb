# frozen_string_literal: true

module Asciidoctor
  VERSION = '2.1.0.alpha.0'
end
