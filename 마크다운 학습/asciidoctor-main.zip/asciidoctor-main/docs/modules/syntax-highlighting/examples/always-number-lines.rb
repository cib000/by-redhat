def highlight node, source, lang, opts
  opts[:number_lines] = true
  super
end
