---
layout: about
title: Contact
description: Get in touch with the Markdown Guide's maintainer.
---

## Email

Feel free to email me at <a href="mailto:matt@macinstruct.com">matt@macinstruct.com</a>. I can't reply to every message, but I do read them all.
