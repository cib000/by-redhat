/* eslint-disable class-methods-use-this */
class MutationObserver {
  observe() {
  }
}
window.MutationObserver = MutationObserver;
