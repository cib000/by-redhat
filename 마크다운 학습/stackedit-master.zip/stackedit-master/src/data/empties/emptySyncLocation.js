export default (id = null) => ({
  id,
  type: 'syncLocation',
  providerId: null,
  fileId: null,
  hash: 0,
});
