export default (id = null) => ({
  id,
  type: 'syncedContent',
  historyData: {},
  syncHistory: {},
  v: 0,
  hash: 0,
});
