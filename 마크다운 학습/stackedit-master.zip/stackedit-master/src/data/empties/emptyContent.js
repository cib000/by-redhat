export default (id = null) => ({
  id,
  type: 'content',
  text: '\n',
  properties: '\n',
  discussions: {},
  comments: {},
  hash: 0,
});
