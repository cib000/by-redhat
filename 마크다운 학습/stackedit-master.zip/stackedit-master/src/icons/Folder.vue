<template>
  <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 24 24">
    <path d="M10,4H4C2.89,4 2,4.89 2,6V18C2,19.1 2.9,20 4,20H20C21.1,20 22,19.1 22,18V8C22,6.89 21.1,6 20,6H12L10,4Z" />
  </svg>
</template>
