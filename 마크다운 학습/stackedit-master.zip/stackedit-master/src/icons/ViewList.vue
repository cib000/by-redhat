<template>
  <svg xmlns="http://www.w3.org/2000/svg" class="icon" viewBox="0 0 24 24">
    <path d="M 9,5L 9,9L 21,9L 21,5M 9,19L 21,19L 21,15L 9,15M 9,14L 21,14L 21,10L 9,10M 4,9L 8,9L 8,5L 4,5M 4,19L 8,19L 8,15L 4,15M 4,14L 8,14L 8,10L 4,10L 4,14 Z "/>
  </svg>
</template>
