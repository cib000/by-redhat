<template>
  <div class="splash-screen">
    <div class="splash-screen__inner logo-background"></div>
  </div>
</template>

<style lang="scss">
.splash-screen {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  padding: 25px;
}

.splash-screen__inner {
  margin: 0 auto;
  max-width: 600px;
  height: 100%;
}
</style>
