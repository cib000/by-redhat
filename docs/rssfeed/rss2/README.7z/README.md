> [!CAUTION]
> 정리는 되었지만 링크가 동작하지 않을 수 있습니다.    
   
> [!NOTE]
> RSS 리더 툴    
> [1](https://www.newzcrawler.com/)https://www.newzcrawler.com/    
> [2](https://www.sharpreader.net/)https://www.sharpreader.net/    
> [3](http://www.bradsoft.com/)http://www.bradsoft.com/    

> [!TIP]
> 크롬 앱스토어
> https://play.google.com/store/apps/details?id=com.vsok.service.rssparser&hl=ko    
   
------
    
     
# RSS FEED 모음
   

> 링크 모음

![AI타임즈](./imgs/aitimes_logo.png)
https://www.aitimes.com/
     
![PR 뉴스와이어](./imgs/prn_cision_logo_desktop.png)
Cision PR Newswire https://www.prnewswire.com/kr/rss/      

BBC 뉴스 코리아 
https://www.bbc.com/korean      
      
      
	  
	  
	  
      
      
https://news-ex.jtbc.co.kr/v1/get/rss/section/entertainment


## 아주경제 RSS      
      
속보 https://www.ajunews.com/rss/sokbo.xml      
중국 https://www.ajunews.com/rss/china.xml      
AI https://www.ajunews.com/rss/ai.xml      
산업 https://www.ajunews.com/rss/industry.xml      
재테크 https://www.ajunews.com/rss/investment.xml      
경제 https://www.ajunews.com/rss/economy.xml      
정치 https://www.ajunews.com/rss/politics.xml      
사회 https://www.ajunews.com/rss/society.xml      
국제 https://www.ajunews.com/rss/global.xml      
포토 https://www.ajunews.com/rss/photo.xml      
문화·연예 https://www.ajunews.com/rss/cultureentertainment.xml      
보도자료 https://www.ajunews.com/rss/presskit.xml      
디지털랩 https://www.ajunews.com/rss/digitallab.xml      
        
	  	  
## 일요신문      
      
전체	https://www.ilyo.co.kr/rss/category	          
특종/단독	https://www.ilyo.co.kr/rss/category/3	          
정치	https://www.ilyo.co.kr/rss/category/6	          
경제	https://www.ilyo.co.kr/rss/category/7	          
사회	https://www.ilyo.co.kr/rss/category/8	          
연예	https://www.ilyo.co.kr/rss/category/13	          
스포츠	https://www.ilyo.co.kr/rss/category/17	          
문화	https://www.ilyo.co.kr/rss/category/21	          
전국	https://www.ilyo.co.kr/rss/category/10	          
월드	https://www.ilyo.co.kr/rss/category/28	          
일요eye	https://www.ilyo.co.kr/rss/category/253	          
멀티미디어	https://www.ilyo.co.kr/rss/category/34	          
연재	https://www.ilyo.co.kr/rss/category/51	          
만화	https://www.ilyo.co.kr/rss/category/37	          
끼 페스티벌	https://www.ilyo.co.kr/rss/category/229
	  
	  
## 뉴스핌 RSS     
      
최신뉴스	http://rss.newspim.com/news/category/1	          
정치	http://rss.newspim.com/news/category/101	          
경제	http://rss.newspim.com/news/category/103	          
사회	http://rss.newspim.com/news/category/102	          
글로벌	http://rss.newspim.com/news/category/107	          
중국	http://rss.newspim.com/news/category/120	          
산업	http://rss.newspim.com/news/category/106	          
증권·금융	http://rss.newspim.com/news/category/105	          
부동산	http://rss.newspim.com/news/category/104	          
전국	http://rss.newspim.com/news/category/108	          
라이프·여행	http://rss.newspim.com/news/category/112	          
문화·연예	http://rss.newspim.com/news/category/110	          
스포츠	http://rss.newspim.com/news/category/111	          
포토	http://rss.newspim.com/news/category/116	          
영상	http://rss.newspim.com/news/category/117      
      
      
##  KISA 한국인터넷진흥원에서 제공하는 RSS
      
공지사항	https://kisa.or.kr/rss/401      
보도자료	https://kisa.or.kr/rss/402      
입찰공고	https://kisa.or.kr/rss/403      
연구보고서	https://kisa.or.kr/rss/201      
      
      
## 국민일보 RSS      
	      
정치	https://www.kmib.co.kr/rss/data/kmibPolRss.xml	 
경제	https://www.kmib.co.kr/rss/data/kmibEcoRss.xml	 
사회	https://www.kmib.co.kr/rss/data/kmibSocRss.xml	 
국제	https://www.kmib.co.kr/rss/data/kmibIntRss.xml	 
연예	https://www.kmib.co.kr/rss/data/kmibEntRss.xml	 
스포츠	https://www.kmib.co.kr/rss/data/kmibSpoRss.xml	 
골프	https://www.kmib.co.kr/rss/data/kmibGolfRss.xml	 
라이프	https://www.kmib.co.kr/rss/data/kmibLifeRss.xml	 
여행	https://www.kmib.co.kr/rss/data/kmibTraRss.xml	 
	 
	 
## 이투데이 RSS 서비스      
      
이투데이 전체뉴스	https://rss.etoday.co.kr/eto/etoday_news_all.xml      
오피니언	https://rss.etoday.co.kr/eto/opinion_news.xml      
증권·금융 뉴스	https://rss.etoday.co.kr/eto/finance_news.xml      
부동산 뉴스	https://rss.etoday.co.kr/eto/land_news.xml      
기업 뉴스	https://rss.etoday.co.kr/eto/company_news.xml      
글로벌경제 뉴스	https://rss.etoday.co.kr/eto/global_news.xml      
정치·경제 뉴스	https://rss.etoday.co.kr/eto/political_economic_news.xml      
사회 뉴스	https://rss.etoday.co.kr/eto/social_news.xml      
문화·라이프 뉴스	https://rss.etoday.co.kr/eto/culturelife_news.xml      
뉴스발전소	https://rss.etoday.co.kr/eto/newsplant_news.xml      
      	  
      
## 미디어 오늘    
    
전체기사	https://www.mediatoday.co.kr/rss/allArticle.xml      
인기기사	https://www.mediatoday.co.kr/rss/clickTop.xml      
정치	https://www.mediatoday.co.kr/rss/S1N2.xml      
경제	https://www.mediatoday.co.kr/rss/S1N3.xml          
사회	https://www.mediatoday.co.kr/rss/S1N4.xml                
생활/문화 https://www.mediatoday.co.kr/rss/S1N5.xml          
세계	https://www.mediatoday.co.kr/rss/S1N6.xml          
IT/과학	https://www.mediatoday.co.kr/rss/S1N7.xml          
오피니언	https://www.mediatoday.co.kr/rss/S1N8.xml          
동영상	https://www.mediatoday.co.kr/rss/S1N10.xml          
      
	  	  
## 삼성 뉴스룸    
삼성 뉴스룸 https://news.samsung.com/feed     
     
	  
## 연합뉴스 경제 TV      
      
전체기사	 https://www.yonhapnewseconomytv.com/rss/allArticle.xml      
인기기사	 https://www.yonhapnewseconomytv.com/rss/clickTop.xml	   
      
      
## 한국인터넷진흥원      
      
취약점 정보 https://knvd.krcert.or.kr/rss/securityInfo.do      
보안공지  https://knvd.krcert.or.kr/rss/securityNotice.do        
      
      
     
## 아이뉴스24의 RSS      
      
IT https://www.inews24.com/rss/news_it.xml      
경제 https://www.inews24.com/rss/news_economy.xml      
정치 https://www.inews24.com/rss/news_politics.xml      
사회 https://www.inews24.com/rss/news_society.xml      
문화 https://www.inews24.com/rss/news_culture.xml      
생활 https://www.inews24.com/rss/news_life.xml      
연예 https://www.inews24.com/rss/news_enter.xml      
스포츠 https://www.inews24.com/rss/news_sports.xml      
	  
	  
## 뉴시스 RSS 서비스    
    
속보 https://www.newsis.com/RSS/sokbo.xml        
정치 https://www.newsis.com/RSS/politics.xml        
국제 https://www.newsis.com/RSS/international.xml        
경제 https://www.newsis.com/RSS/economy.xml        
금융 https://www.newsis.com/RSS/bank.xml        
산업 https://www.newsis.com/RSS/industry.xml        
사회 https://www.newsis.com/RSS/society.xml        
IT·바이오 https://www.newsis.com/RSS/health.xml        
수도권 https://www.newsis.com/RSS/met.xml        
지방 https://www.newsis.com/RSS/country.xml        
스포츠 https://www.newsis.com/RSS/sports.xml        
연예 https://www.newsis.com/RSS/entertain.xml        
문화 https://www.newsis.com/RSS/culture.xml        
광장 https://www.newsis.com/RSS/square.xml        
포토 https://www.newsis.com/RSS/photo.xml        
위클리뉴시스 https://www.newsis.com/RSS/newsiseyes.xml        
        
		
## 국토교통부 제공 RSS     
     
공지사항	https://www.molit.go.kr/dev/board/board_rss.jsp?rss_id=N01_B     
직원채용공고	https://www.molit.go.kr/dev/board/board_rss.jsp?rss_id=N0303_B     
자격시험안내	https://www.molit.go.kr/dev/board/board_rss.jsp?rss_id=N04_B     
보도자료	https://www.molit.go.kr/dev/board/board_rss.jsp?rss_id=NEWS     
인사·채용	https://www.molit.go.kr/dev/board/board_rss.jsp?rss_id=INSA     
입찰안내	https://www.molit.go.kr/dev/board/board_rss.jsp?rss_id=tender     
     
     
## 한국경제 RSS    
    
전체뉴스 https://www.hankyung.com/feed/all-news    
증권 https://www.hankyung.com/feed/finance    
경제 https://www.hankyung.com/feed/economy    
부동산 https://www.hankyung.com/feed/realestate    
IT https://www.hankyung.com/feed/it    
정치 https://www.hankyung.com/feed/politics    
국제 https://www.hankyung.com/feed/international    
사회 https://www.hankyung.com/feed/society    
생활 https://www.hankyung.com/feed/life    
오피니언 https://www.hankyung.com/feed/opinion    
스포츠 https://www.hankyung.com/feed/sports    
연예 https://www.hankyung.com/feed/entertainment    
VIDEO https://www.hankyung.com/feed/video    
     
    	 
## 금융위원회 RSS 주소    
    
알림마당 > 위원회 소식 > 보도자료	http://www.fsc.go.kr/about/fsc_bbs_rss/?fid=0111    
알림마당 > 위원회 소식 > 보도설명	http://www.fsc.go.kr/about/fsc_bbs_rss/?fid=0112    
알림마당 > 위원회 소식 > 공지사항	http://www.fsc.go.kr/about/fsc_bbs_rss/?fid=0114    
알림마당 > 홍보자료 > 카드뉴스	http://www.fsc.go.kr/about/fsc_card_rss/?fid=0411    
    
    
## 경기도 뉴스포털 RSS    
경기도 뉴스포털 RSS     
      
경제	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E001&policyCode=E001          
복지	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E002&policyCode=E002      
교육	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E003&policyCode=E003      
주택	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E004&policyCode=E004      
환경	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E005&policyCode=E005      
문화	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E006&policyCode=E006      
교통	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E007&policyCode=E007      
안전	 https://gnews.gg.go.kr/rss/categoryRssSearch.do?kwd=E008&policyCode=E008      
보도자료	 https://gnews.gg.go.kr/rss/gnewsRssBodo.do      
경기뉴스광장	https://gnews.gg.go.kr/rss/gnewsZoneRss.do      
일일뉴스	https://gnews.gg.go.kr/rss/gnewsDailyRss.do      
나의 경기도	https://gnews.gg.go.kr/rss/gnewsMyGyeonggiRss.do      
피드리더 http://www.feedreader.com      
RSSOwl(설치형) http://www.rssowl.org      

	

## 노컷뉴스    
노컷뉴스 RSS https://www.nocutnews.co.kr/rss/
    
	
## 뉴스 와이어    
    
뉴스 와이어 RSS 주소 https://www.newswire.co.kr/?md=A31    
    
    
    
	
## KBS WORLD Radio RSS 서비스    
    
연예가 소식	http://world.kbs.co.kr/rss/rss_enternews.htm?lang=k    
    
	
	
	
## 전자신문인터넷 기사별 RSS 서비스 주소    
    
오늘의 뉴스 RSS http://rss.etnews.com/Section901.xml    
뉴스속보 RSS http://rss.etnews.com/Section902.xml    
오늘의 인기기사 RSS http://rss.etnews.com/Section903.xml    
오늘의 추천기사 RSS http://rss.etnews.com/Section904.xml    
경제 RSS http://rss.etnews.com/02.xml    
경제 RSS http://rss.etnews.com/02024.xml    
금융 RSS http://rss.etnews.com/02027.xml    
모빌리티 RSS http://rss.etnews.com/17.xml    
모빌리티 RSS http://rss.etnews.com/17066.xml    
IT RSS http://rss.etnews.com/03.xml    
통신 RSS http://rss.etnews.com/03033.xml    
방송 RSS http://rss.etnews.com/03025.xml    
게임 RSS http://rss.etnews.com/03104.xml    
전자 RSS http://rss.etnews.com/06.xml    
전자 RSS http://rss.etnews.com/06063.xml    
소재 RSS http://rss.etnews.com/06064.xml    
부품 RSS http://rss.etnews.com/06062.xml    
장비 RSS http://rss.etnews.com/06061.xml    
중공업 RSS http://rss.etnews.com/06065.xml    
SW RSS http://rss.etnews.com/04.xml    
SW RSS http://rss.etnews.com/04043.xml    
보안 RSS http://rss.etnews.com/04045.xml    
AI RSS http://rss.etnews.com/04046.xml    
과학 RSS http://rss.etnews.com/20.xml    
과학 RSS http://rss.etnews.com/20020.xml    
바이오 RSS http://rss.etnews.com/20042.xml    
플랫폼/유통 RSS http://rss.etnews.com/60.xml    
플랫폼 RSS http://rss.etnews.com/60028.xml    
유통 RSS http://rss.etnews.com/60068.xml    
정치 RSS http://rss.etnews.com/16.xml    
정책 RSS http://rss.etnews.com/22210.xml    
정치 RSS http://rss.etnews.com/22220.xml    
교육 RSS http://rss.etnews.com/22230.xml    
중기/벤처 RSS http://rss.etnews.com/22069.xml    
전국 RSS http://rss.etnews.com/25.xml    
국제 RSS http://rss.etnews.com/12.xml    
오피니언 RSS http://rss.etnews.com/11.xml    
칼럼 RSS http://rss.etnews.com/11011.xml    
피플 RSS http://rss.etnews.com/11350.xml    
인사부음 RSS http://rss.etnews.com/11351.xml    
    
    
        
        
        
## 경향신문     
     
전체뉴스 https://www.khan.co.kr/rss/rssdata/total_news.xml     
만평 https://www.khan.co.kr/rss/rssdata/cartoon_news.xml     
오피니언 https://www.khan.co.kr/rss/rssdata/opinion_news.xml     
정치 https://www.khan.co.kr/rss/rssdata/politic_news.xml     
경제 https://www.khan.co.kr/rss/rssdata/economy_news.xml     
사회 https://www.khan.co.kr/rss/rssdata/society_news.xml     
지역 https://www.khan.co.kr/rss/rssdata/local_news.xml     
국제 https://www.khan.co.kr/rss/rssdata/kh_world.xml     
문화 https://www.khan.co.kr/rss/rssdata/culture_news.xml     
스포츠 http://www.khan.co.kr/rss/rssdata/kh_sports.xml     
과학·환경 https://www.khan.co.kr/rss/rssdata/science_news.xml     
라이프 http://www.khan.co.kr/rss/rssdata/life_news.xml     
사람 https://www.khan.co.kr/rss/rssdata/people_news.xml     
영문 https://www.khan.co.kr/rss/rssdata/english_news.xml     
뉴스레터 https://www.khan.co.kr/rss/rssdata/newsletter_news.xml     
인터랙티브 https://www.khan.co.kr/rss/rssdata/interactive_news.xml     
     
     
     
	 
## 동아닷컴    
    
전체기사 https://rss.donga.com/total.xml    
정치 https://rss.donga.com/politics.xml    
사회 https://rss.donga.com/national.xml    
경제 https://rss.donga.com/economy.xml    
국제 https://rss.donga.com/international.xml    
사설칼럼 https://rss.donga.com/editorials.xml    
의학과학 https://rss.donga.com/science.xml    
문화연예 https://rss.donga.com/culture.xml    
스포츠 https://rss.donga.com/sports.xml    
사람속으로 https://rss.donga.com/inmul.xml    
건강 https://rss.donga.com/health.xml    
레저 https://rss.donga.com/leisure.xml    
도서 https://rss.donga.com/book.xml    
공연 https://rss.donga.com/show.xml    
여성 https://rss.donga.com/woman.xml    
여행 https://rss.donga.com/travel.xml    
생활정보 https://rss.donga.com/lifeinfo.xml    
스포츠동아    
스포츠 https://rss.donga.com/sportsdonga/sports.xml    
야구&MLB https://rss.donga.com/sportsdonga/baseball.xml    
축구 https://rss.donga.com/sportsdonga/soccer.xml    
골프 https://rss.donga.com/sportsdonga/golf.xml    
스포츠 일반 https://rss.donga.com/sportsdonga/sports_general.xml    
e스포츠 & 게임 https://rss.donga.com/sportsdonga/sports_game.xml    
엔터테인먼트 https://rss.donga.com/sportsdonga/entertainment.xml    
    
    
    
	
## 매일경제    
    
뉴스    
헤드라인 https://www.mk.co.kr/rss/30000001/    
전체뉴스 https://www.mk.co.kr/rss/40300001/    
뉴스 경제 https://www.mk.co.kr/rss/30100041/    
뉴스 정치 https://www.mk.co.kr/rss/30200030/    
뉴스 사회 https://www.mk.co.kr/rss/50400012/    
뉴스 국제 https://www.mk.co.kr/rss/30300018/    
뉴스 기업·경영 https://www.mk.co.kr/rss/50100032/    
뉴스 증권 https://www.mk.co.kr/rss/50200011/    
뉴스 부동산 https://www.mk.co.kr/rss/50300009/    
뉴스 문화·연예 https://www.mk.co.kr/rss/30000023/    
뉴스 스포츠 https://www.mk.co.kr/rss/71000001/    
뉴스 게임 https://www.mk.co.kr/rss/50700001/    
특집기사 MBA https://www.mk.co.kr/rss/40200124/    
특집기사 머니 앤 리치스 https://www.mk.co.kr/rss/40200003/    
영문뉴스 Top Stories(English Edition) https://www.mk.co.kr/rss/30800011/    
이코노미 전체기사 https://www.mk.co.kr/rss/50000001/    
시티라이프 전체기사 https://www.mk.co.kr/rss/60000007/    
    
    
    
## 오마이뉴스 기사별        
        
오마이뉴스 기사별        
오마이뉴스 전체기사 https://rss.ohmynews.com/rss/ohmynews.xml        
오마이뉴스 주요기사 https://rss.ohmynews.com/rss/top.xml        
오마이포토 오늘의사진 https://rss.ohmynews.com/rss/todayphoto.xml        
사는이야기 https://rss.ohmynews.com/rss/life.xml        
사회 https://rss.ohmynews.com/rss/society.xml        
문화 https://rss.ohmynews.com/rss/culture.xml        
정치 https://rss.ohmynews.com/rss/politics.xml        
경제 https://rss.ohmynews.com/rss/economy.xml        
민족·국제 https://rss.ohmynews.com/rss/international.xml        
교육 https://rss.ohmynews.com/rss/education.xml        
미디어 https://rss.ohmynews.com/rss/media.xml        
여행 https://rss.ohmynews.com/rss/travel.xml        
책동네 https://rss.ohmynews.com/rss/book.xml        
여성 https://rss.ohmynews.com/rss/woman.xml        
만화만평 https://rss.ohmynews.com/rss/cartoon.xml        
광주전라 https://rss.ohmynews.com/rss/jeolla.xml        
부산경남 https://rss.ohmynews.com/rss/gyeongnam.xml        
대전충청 https://rss.ohmynews.com/rss/chungnam.xml        
인천경기 https://rss.ohmynews.com/rss/gyeonggi.xml        
대구경북 https://rss.ohmynews.com/rss/kyungbuk.xml        
강원제주https://rss.ohmynews.com/rss/gangwonjeju.xml
오마이스타        
오마이스타 전체기사 https://rss.ohmynews.com/rss/star.xml        
오마이스타 주요기사 https://rss.ohmynews.com/rss/startop.xml        
스포츠 https://rss.ohmynews.com/rss/sports.xml기사보기주소복사        
오마이TV        
오마이TV 전체영상 https://rss.ohmynews.com/rss/ohmytv.xml        
오연호가 묻다 https://rss.ohmynews.com/rss/tvohask.xml        
박정호의 핫스팟 https://rss.ohmynews.com/rss/tvhotspot.xml        
저자와의 대화 https://rss.ohmynews.com/rss/tvauthortalk.xml        
오마이TV 쏙쏙뉴스https://rss.ohmynews.com/rss/tvssnews.xml        
        
        
		
		
## SBS 뉴스    
    
이 시각 인기 https://news.sbs.co.kr/news/TopicRssFeed.do?plink=RSSREADER    
분야별 뉴스     
최신  https://news.sbs.co.kr/news/newsflashRssFeed.do?plink=RSSREADER    
정치  https://news.sbs.co.kr/news/SectionRssFeed.do?sectionId=01&plink=RSSREADER    
경제  https://news.sbs.co.kr/news/SectionRssFeed.do?sectionId=02&plink=RSSREADER    
사회  https://news.sbs.co.kr/news/SectionRssFeed.do?sectionId=03&plink=RSSREADER    
국제  https://news.sbs.co.kr/news/SectionRssFeed.do?sectionId=07&plink=RSSREADER    
생활 ∙ 문화  https://news.sbs.co.kr/news/SectionRssFeed.do?sectionId=08&plink=RSSREADER    
연예  https://news.sbs.co.kr/news/SectionRssFeed.do?sectionId=14&plink=RSSREADER    
스포츠  https://news.sbs.co.kr/news/SectionRssFeed.do?sectionId=09&plink=RSSREADER    
취재파일  https://news.sbs.co.kr/news/Special_RssFeed.do?plink=RSSREADER    
비디오머그  https://news.sbs.co.kr/news/VideoMug_RssFeed.do?plink=RSSREADER    
스브스뉴스  https://news.sbs.co.kr/news/Subusu_RssFeed.do?plink=RSSREADER    
뉴스 프로그램    
8뉴스  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=R1&plink=RSSREADER    
모닝와이드  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=R2&plink=RSSREADER    
뉴스브리핑  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=RN&plink=RSSREADER    
오뉴스  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=RO&plink=RSSREADER    
나이트라인  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=R5&plink=RSSREADER    
뉴스토리  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=RJ&plink=RSSREADER    
뉴스특보  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=RS&plink=RSSREADER    
뉴스헌터스  https://news.sbs.co.kr/news/ReplayRssFeed.do?prog_cd=RH&plink=RSSREADER    
	
	
	
	
	
## 보안뉴스    
    
메인 카테고리
SECURITY http://www.boannews.com/media/news_rss.xml?mkind=1    
IT		http://www.boannews.com/media/news_rss.xml?mkind=2    
SAFETY		http://www.boannews.com/media/news_rss.xml?mkind=4    
SecurityWorld		http://www.boannews.com/media/news_rss.xml?mkind=5    
뉴스 카테고리    
전체기사		http://www.boannews.com/media/news_rss.xml    
사건ㆍ사고		http://www.boannews.com/media/news_rss.xml?kind=1    
공공ㆍ정책		http://www.boannews.com/media/news_rss.xml?kind=2    
비즈니스		    http://www.boannews.com/media/news_rss.xml?kind=3    
국제		http://www.boannews.com/media/news_rss.xml?kind=4    
테크		http://www.boannews.com/media/news_rss.xml?kind=5    
오피니언		http://www.boannews.com/media/news_rss.xml?kind=6    
세부 카테고리    
긴급경보		http://www.boannews.com/media/news_rss.xml?skind=5    
기획특집		http://www.boannews.com/media/news_rss.xml?skind=7    
인터뷰		http://www.boannews.com/media/news_rss.xml?skind=3    
보안컬럼		http://www.boannews.com/media/news_rss.xml?skind=2    
보안정책		http://www.boannews.com/media/news_rss.xml?skind=6    
    	
    	
    	
    	
## 조선일보    
    		
전체기사	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/?outputType=xml     
정치	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/politics/?outputType=xml     
경제	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/economy/?outputType=xml     
사회	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/national/?outputType=xml     
국제	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/international/?outputType=xml     
문화/라이프	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/culture-life/?outputType=xml     
오피니언	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/opinion/?outputType=xml     
스포츠	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/sports/?outputType=xml     
연예	RSS 퍼가기	https://www.chosun.com/arc/outboundfeeds/rss/category/entertainments/?outputType=xml     
		
영문 조선	RSS 퍼가기	https://english.chosun.com/site/data/rss/rss.xml     


## 연합뉴스 TV    
      
http://www.yonhapnewstv.co.kr/browse/feed/    
정치http://www.yonhapnewstv.co.kr/category/news/politics/feed/    
경제http://www.yonhapnewstv.co.kr/category/news/economy/feed/    
사회http://www.yonhapnewstv.co.kr/category/news/society/feed/    
지역http://www.yonhapnewstv.co.kr/category/news/local/feed/    


## 연합뉴스    
      
최신기사 https://www.yna.co.kr/rss/news.xml     
정치 https://www.yna.co.kr/rss/politics.xml     
북한 https://www.yna.co.kr/rss/northkorea.xml     
경제 https://www.yna.co.kr/rss/economy.xml     
마켓+ https://www.yna.co.kr/rss/market.xml     
산업 https://www.yna.co.kr/rss/industry.xml     
사회 https://www.yna.co.kr/rss/society.xml     
전국 https://www.yna.co.kr/rss/local.xml     
세계 https://www.yna.co.kr/rss/international.xml     
문화 https://www.yna.co.kr/rss/culture.xml     
건강 https://www.yna.co.kr/rss/health.xml     
연예 https://www.yna.co.kr/rss/entertainment.xml     
스포츠 https://www.yna.co.kr/rss/sports.xml     
오피니언 https://www.yna.co.kr/rss/opinion.xml     
사람들 https://www.yna.co.kr/rss/people.xml      


## JTBC 뉴스의 RSS    
[JTBC 뉴스의 RSS](https://news.jtbc.co.kr/rss)   
        
속보    
https://news-ex.jtbc.co.kr/v1/get/rss/newsflesh    
이슈 Top10    
https://news-ex.jtbc.co.kr/v1/get/rss/issue    
분야별 뉴스    
정치    
https://news-ex.jtbc.co.kr/v1/get/rss/section/politics    
경제    
https://news-ex.jtbc.co.kr/v1/get/rss/section/economy    
사회    
https://news-ex.jtbc.co.kr/v1/get/rss/section/society    
국제    
https://news-ex.jtbc.co.kr/v1/get/rss/section/international    
문화    
https://news-ex.jtbc.co.kr/v1/get/rss/section/culture    
연예    
https://news-ex.jtbc.co.kr/v1/get/rss/section/entertainment    
스포츠    
https://news-ex.jtbc.co.kr/v1/get/rss/section/sports    
날씨    
https://news-ex.jtbc.co.kr/v1/get/rss/section/weather    
주요 프로그램    
이가혁 라이브    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000024    
장르가 머니    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000023    
논/쟁    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000022    
장르만 여의도    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000019    
알탭    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000018    
부글터뷰·몽글터뷰    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000017    
백브RE핑    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000016    
이 시각 뉴스룸    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000015    
사건반장    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000014    
JTBC 뉴스특보    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000013    
아침&    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000011    
JTBC 뉴스룸    
https://news-ex.jtbc.co.kr/v1/get/rss/program/NG10000002    
    
    
    	
## 시사인사이트   

전체기사 https://www.sisainlive.com/rss.xml         
인기기사 https://www.sisainlive.com/rss/clickTop.xml         
커버스토리 https://www.sisainlive.com/rss/SRN121.xml         
특집 https://www.sisainlive.com/rss/SRN122.xml         
정치 https://www.sisainlive.com/rss/S1N15.xml         
경제 https://www.sisainlive.com/rss/S1N16.xml         
사회 https://www.sisainlive.com/rss/S1N17.xml         
문화 https://www.sisainlive.com/rss/S1N18.xml         
국제.한반도 https://www.sisainlive.com/rss/S1N4.xml         
실용.과학 https://www.sisainlive.com/rss/S1N6.xml         
휴먼&휴 https://www.sisainlive.com/rss/S1N19.xml         
인터뷰.오피니언 https://www.sisainlive.com/rss/S1N5.xml         
사진.만화 https://www.sisainlive.com/rss/S1N7.xml         
별책부록 https://www.sisainlive.com/rss/S1N14.xml         
   
   
## 경향닷컴   
[경향신문]전체뉴스 https://www.khan.co.kr/rss/rssdata/total_news.xml      
[경향신문]오피니언 https://www.khan.co.kr/rss/rssdata/opinion.xml      
[경향신문]정치 https://www.khan.co.kr/rss/rssdata/politic.xml      
[경향신문]경제 https://www.khan.co.kr/rss/rssdata/economy.xml      
[경향신문]사회 https://www.khan.co.kr/rss/rssdata/society.xml      
[경향신문]문화 https://www.khan.co.kr/rss/rssdata/culture.xml      
[경향신문]IT과학 https://www.khan.co.kr/rss/rssdata/itnews.xml      
[경향신문]국제 https://www.khan.co.kr/rss/rssdata/world.xml      
[경향신문]스포츠 https://www.khan.co.kr/rss/rssdata/sports.xml      
[경향신문]매거진X https://www.khan.co.kr/rss/rssdata/mx.xml      
[경향신문]인물 https://www.khan.co.kr/rss/rssdata/people.xml      
[스포츠]스포츠전체 https://www.khan.co.kr/rss/rssdata/kh_sports.xml      
[스포츠]엔터테인먼트 https://www.khan.co.kr/rss/rssdata/kh_entertainment.xml      
[스포츠]펀 https://www.khan.co.kr/rss/rssdata/kh_fun.xml      
[스포츠]운세 https://www.khan.co.kr/rss/rssdata/kh_unse.xml      
[스포츠]기획 https://www.khan.co.kr/rss/rssdata/kh_special.xml      
         
         
         
##허핑턴포스트         

피드 https://www.huffingtonpost.kr/feeds/verticals/korea/index.xml      
블로그 https://www.huffingtonpost.kr/feeds/verticals/korea/blog.xml      
뉴스 https://www.huffingtonpost.kr/feeds/verticals/korea/news.xml      
         
		          
				  
## MBC
         
[뉴스]전체 https://imnews.imbc.com/rss/news/news_00.xml      
[뉴스]정치 https://imnews.imbc.com/rss/news/news_01.xml      
[뉴스]통일외교 https://imnews.imbc.com/rss/news/news_02.xml      
[뉴스]국제 https://imnews.imbc.com/rss/news/news_03.xml      
[뉴스]경제 https://imnews.imbc.com/rss/news/news_04.xml      
[뉴스]사회 https://imnews.imbc.com/rss/news/news_05.xml      
[뉴스]문화/연예 https://imnews.imbc.com/rss/news/news_06.xml      
[뉴스]스포츠 https://imnews.imbc.com/rss/news/news_07.xml      
[뉴스]건강/과학 https://imnews.imbc.com/rss/news/news_08.xml      
[다시보기]뉴스데스크 https://imnews.imbc.com/rss/replay/replay_01.xml      
[다시보기]뉴스투데이 https://imnews.imbc.com/rss/replay/replay_02.xml      
[다시보기]1045뉴스 https://imnews.imbc.com/rss/replay/replay_03.xml      
[다시보기]뉴스와경제 https://imnews.imbc.com/rss/replay/replay_04.xml      
[다시보기]5시뉴스 https://imnews.imbc.com/rss/replay/replay_05.xml      
[다시보기]저녁뉴스 https://imnews.imbc.com/rss/replay/replay_06.xml      
[다시보기]스포츠뉴스 https://imnews.imbc.com/rss/replay/replay_07.xml      
[다시보기]뉴스24 https://imnews.imbc.com/rss/replay/replay_08.xml      
[위클리]시사매거진2580 https://imnews.imbc.com/rss/weekly/weekly_01.xml      
[위클리]100분토론 https://imnews.imbc.com/rss/weekly/weekly_02.xml      
[위클리]뉴스후 https://imnews.imbc.com/rss/weekly/weekly_03.xml      
[위클리]지구촌리포트 https://imnews.imbc.com/rss/weekly/weekly_04.xml      
[위클리]통일전망대 https://imnews.imbc.com/rss/weekly/weekly_07.xml      
[위클리]경제매거진M https://imnews.imbc.com/rss/weekly/weekly_05.xml      
[위클리]일요인터뷰人 https://imnews.imbc.com/rss/weekly/weekly_08.xml      
[위클리]스포츠매거진 https://imnews.imbc.com/rss/weekly/weekly_06.xml      
[영상]라이브풀영상 https://imnews.imbc.com/rss/fullmov/fullmov_01.xml      
[영상]MBC풀영상 https://imnews.imbc.com/rss/fullmov/fullmov_02.xml      
[영상]해외풀영상 https://imnews.imbc.com/rss/fullmov/fullmov_03.xml      
[영상]스포츠풀영상 https://imnews.imbc.com/rss/fullmov/fullmov_04.xml      
[영상]토론회풀영상 https://imnews.imbc.com/rss/fullmov/fullmov_05.xml      
[영상]연예풀영상 https://imnews.imbc.com/rss/fullmov/fullmov_06.xml      
기자칼럼 https://imnews.imbc.com/rss/mpeople/rptcolumn.xml      
시민기자뉴스 https://imnews.imbc.com/rss/citizen/movnews.xml      
         
		          
				  
## 조선닷컴         

[뉴스]전체기사 https://www.chosun.com/site/data/rss/rss.xml      
[뉴스]오늘의 주요뉴스 https://myhome.chosun.com/rss/www_section_rss.xml      
[뉴스]정치 https://www.chosun.com/site/data/rss/politics.xml      
[뉴스]국제 https://www.chosun.com/site/data/rss/international.xml      
[뉴스]문화 https://www.chosun.com/site/data/rss/culture.xml      
[뉴스]사설ㆍ칼럼 https://www.chosun.com/site/data/rss/editorials.xml      
[뉴스]동영상 https://www.chosun.com/site/data/rss/video.xml      
[뉴스]인포그래픽 뉴스 https://inside.chosun.com/rss/rss.xml      
[뉴스]포토 https://photo.chosun.com/site/data/rss/photonews.xml      
[뉴스]랭킹 (인기기사) https://newsplus.chosun.com/hitdata/xml/index/index.xml      
[조선비즈]전체기사 https://biz.chosun.com/site/data/rss/rss.xml      
[조선비즈]뉴스 https://biz.chosun.com/site/data/rss/news.xml      
[조선비즈]Market https://biz.chosun.com/site/data/rss/market.xml      
[조선비즈]정책/금융 https://biz.chosun.com/site/data/rss/policybank.xml      
[조선비즈]부동산 https://biz.chosun.com/site/data/rss/estate.xml      
[조선비즈]기업 https://biz.chosun.com/site/data/rss/enterprise.xml      
[조선비즈]글로벌경제 https://biz.chosun.com/site/data/rss/global.xml      
[조선비즈]위클리비즈 https://biz.chosun.com/site/data/rss/weeklybiz.xml      
[조선비즈]랭킹(인기기사) https://newsplus.chosun.com/hitdata/xml/chosunbiz/index/index.xml      
[엔터테인먼트]스포츠 https://www.chosun.com/site/data/rss/sports.xml      
[엔터테인먼트]연예 https://www.chosun.com/site/data/rss/ent.xml      
[엔터테인먼트]더스타 https://thestar.chosun.com/site/data/rss/rss.xml      
[엔터테인먼트]키위닷컴 https://keywui.chosun.com/rss/rss.xml      
[엔터테인먼트]랭킹(인기기사)스포츠 https://newsplus.chosun.com/hitdata/xml/se/sports/index.xml      
[엔터테인먼트]랭킹(인기기사)연예 https://newsplus.chosun.com/hitdata/xml/se/star/index.xml      
[뉴스플러스]뉴스플러스 https://newsplus.chosun.com/site/data/rss/news.xml      
[뉴스플러스]인사이드 https://newsplus.chosun.com/inside/xml/inside_rss.xml      
[뉴스플러스]단미 https://danmee.chosun.com/site/data/rss/rss.xml      
[뉴스플러스]헬스 https://health.chosun.com/site/data/rss/rss.xml      
[뉴스플러스]카리뷰 https://careview.chosun.com/site/data/rss/rss.xml      
[뉴스플러스]트래블N https://travel.chosun.com/site/data/rss/rss.xml      
[뉴스플러스]리뷰 https://review.chosun.com/site/data/rss/rss.xml      
[뉴스플러스]북스 https://books.chosun.com/site/data/rss/rss.xml      
[뉴스플러스]아트N https://art.chosun.com/site/data/rss/rss.xml      
[뉴스플러스]소년조선일보 https://myhome.chosun.com/rss/kid_section_rss.xml      
[뉴스플러스]건강칼럼 https://health.chosun.com/rss/column.xml      
[뉴스플러스]랭킹(인기기사) https://newsplus.chosun.com/hitdata/xml/newsplus/index/index.xml      
[토론마당]시사발언대 https://forum.chosun.com/rss/RSSServlet?bbs_type=S      
[토론마당]천자토론 https://forum.chosun.com/rss/RSSServlet?bbs_type=R      
[토론마당]공감토론 https://forum.chosun.com/rss/RSSServlet?bbs_type=P      



## 중앙일보         
         
[뉴스]전체기사 https://rss.joinsmsn.com/joins_news_list.xml      
[뉴스]주요기사 https://rss.joinsmsn.com/joins_homenews_list.xml      
[뉴스]경제 https://rss.joinsmsn.com/joins_money_list.xml      
[뉴스]사회 https://rss.joinsmsn.com/joins_life_list.xml      
[뉴스]정치 https://rss.joinsmsn.com/joins_politics_list.xml      
[뉴스]라이프 https://rss.joinsmsn.com/news/joins_lifenews_total.xml      
[뉴스]지구촌 https://rss.joinsmsn.com/joins_world_list.xml      
[뉴스]문화 https://rss.joinsmsn.com/joins_culture_list.xml      
[뉴스]IT과학 https://rss.joinsmsn.com/joins_it_list.xml      
[뉴스]건강,IT,과학 https://rss.joinsmsn.com/news/joins_health_list.xml      
[뉴스]J-Only https://rss.joinsmsn.com/news/joins_jonly_list.xml      
[뉴스]CNN한글 https://rss.joinsmsn.com/news/joins_cnnnews_total.xml      
[뉴스]중앙데일리 https://rss.joinsmsn.com/news/joins_joongangdaily_news.xml      
[포토]전체기사 https://rss.joinsmsn.com/photo/joins_photo_list.xml      
[포토]머니 https://rss.joinsmsn.com/photo/joins_photo_list_money.xml      
[포토]스포츠 https://rss.joinsmsn.com/photo/joins_photo_list_sports.xml      
[포토]연예 https://rss.joinsmsn.com/photo/joins_photo_list_star.xml      
[포토]사회 https://rss.joinsmsn.com/photo/joins_photo_list_life.xml      
[포토]정치 https://rss.joinsmsn.com/photo/joins_photo_list_politics.xml      
[포토]지구촌 https://rss.joinsmsn.com/photo/joins_photo_list_world.xml      
[포토]IT https://rss.joinsmsn.com/photo/joins_photo_list_it.xml      
[포토]Hot포토 https://rss.joinsmsn.com/photo/joins_photo_list_hot.xml      
[포토]지구촌화제 https://rss.joinsmsn.com/photo/joins_gallery_list_world.xml      
[포토]사건사고현장 https://rss.joinsmsn.com/photo/joins_gallery_list_news.xml      
[스포츠/연예]스포츠전체 https://rss.joinsmsn.com/joins_sports_list.xml      
[스포츠/연예]연예전체 https://rss.joinsmsn.com/joins_star_list.xml      
[스포츠/연예]야구 https://rss.joinsmsn.com/news/joins_sports_baseball_list.xml      
[스포츠/연예]축구 https://rss.joinsmsn.com/news/joins_sports_soccer_list.xml      
[스포츠/연예]골프 https://rss.joinsmsn.com/news/joins_sports_golf_list.xml      
[스포츠/연예]스포츠일반 https://rss.joinsmsn.com/news/joins_sports_etc_list.xml      
[스포츠/연예]방송 https://rss.joinsmsn.com/news/joins_star_entertainment_list.xml      
[스포츠/연예]영화 https://rss.joinsmsn.com/news/joins_star_movie_list.xml      
[스포츠/연예]연예일반 https://rss.joinsmsn.com/news/joins_star_etc_list.xml      
[많이본뉴스]전체기사 https://rss.joinsmsn.com/sonagi/joins_sonagi_total_list.xml      
[많이본뉴스]경제 https://rss.joinsmsn.com/sonagi/joins_sonagi_money_list.xml      
[많이본뉴스]스포츠 https://rss.joinsmsn.com/sonagi/joins_sonagi_sports_list.xml      
[많이본뉴스]연예 https://rss.joinsmsn.com/sonagi/joins_sonagi_star_list.xml      
[많이본뉴스]사회 https://rss.joinsmsn.com/sonagi/joins_sonagi_life_list.xml      
[많이본뉴스]정치 https://rss.joinsmsn.com/sonagi/joins_sonagi_politics_list.xml      
[많이본뉴스]지구촌 https://rss.joinsmsn.com/sonagi/joins_sonagi_world_list.xml      
[많이본뉴스]IT과학 https://rss.joinsmsn.com/sonagi/joins_sonagi_it_list.xml      
[많이본뉴스]사설 https://rss.joinsmsn.com/sonagi/joins_sonagi_opinion_list.xml      

         
## 노컷뉴스         
         
최신기사 https://rss.nocutnews.co.kr/nocutnews.xml      
정치 https://rss.nocutnews.co.kr/NocutPolitics.xml      
사회 https://rss.nocutnews.co.kr/NocutSocial.xml      
경제 https://rss.nocutnews.co.kr/NocutEconomy.xml      
산업 https://rss.nocutnews.co.kr/NocutIndustry.xml      
스포츠 https://rss.nocutnews.co.kr/NocutSports.xml      
지역 https://rss.nocutnews.co.kr/NocutLocal.xml      
세계 https://rss.nocutnews.co.kr/NocutGlobal.xml      
정보통신 https://rss.nocutnews.co.kr/NocutIT.xml      
연예 https://rss.nocutnews.co.kr/NocutEnter.xml      
문화/생활 https://rss.nocutnews.co.kr/NocutCulture.xml      
포토뉴스 https://rss.nocutnews.co.kr/NocutPhoto.xml      
칼럼 https://rss.nocutnews.co.kr/NocutColum.xml      
기타 https://rss.nocutnews.co.kr/NocutEtc.xml      
노컷특종 https://rss.nocutnews.co.kr/NocutOnly.xml      
핫이슈 https://rss.nocutnews.co.kr/NocutHotissue.xml      
연속기획 https://rss.nocutnews.co.kr/NocutCplan.xml      
         
		 
## 동아닷컴         
         
[동아일보]전체기사 https://rss.donga.com/total.xml      
[동아일보]정치 https://rss.donga.com/politics.xml      
[동아일보]사회 https://rss.donga.com/national.xml      
[동아일보]경제 https://rss.donga.com/economy.xml      
[동아일보]국제 https://rss.donga.com/international.xml      
[동아일보]사설칼럼 https://rss.donga.com/editorials.xml      
[동아일보]의학과학 https://rss.donga.com/science.xml      
[동아일보]문화연예 https://rss.donga.com/culture.xml      
[동아일보]스포츠 https://rss.donga.com/sports.xml      
[동아일보]사람속으로 https://rss.donga.com/inmul.xml      
[동아일보]건강 https://rss.donga.com/health.xml      
[동아일보]레져 https://rss.donga.com/leisure.xml      
[동아일보]도서 https://rss.donga.com/book.xml      
[동아일보]공연 https://rss.donga.com/show.xml      
[동아일보]여성 https://rss.donga.com/woman.xml      
[동아일보]아동 https://rss.donga.com/child.xml      
[동아일보]여행 https://rss.donga.com/travel.xml      
[동아일보]생활정보 https://rss.donga.com/lifeinfo.xml      
[스포츠동아]야구nMLB https://rss.donga.com/sportsdonga/baseball.xml      
[스포츠동아]축구 https://rss.donga.com/sportsdonga/soccer.xml      
[스포츠동아]골프 https://rss.donga.com/sportsdonga/golf.xml      
[스포츠동아]종합 https://rss.donga.com/sportsdonga/sports_general.xml      
[스포츠동아]엔터테인먼트 https://rss.donga.com/sportsdonga/entertainment.xml      



## 세계일보         
         
[뉴스]최신기사 https://rss.segye.com/segye_recent.xml      
[뉴스]종합 https://rss.segye.com/segye_total.xml      
[뉴스]정치 https://rss.segye.com/segye_politic.xml      
[뉴스]국제 https://rss.segye.com/segye_international.xml      
[뉴스]경제 https://rss.segye.com/segye_economy.xml      
[뉴스]사회 https://rss.segye.com/segye_society.xml      
[뉴스]문화 https://rss.segye.com/segye_culture.xml      
[뉴스]스포츠 https://rss.segye.com/segye_sports.xml      
[뉴스]연예 https://rss.segye.com/segye_entertainment.xml      
[뉴스]피플 https://rss.segye.com/segye_people.xml      
[뉴스]오피니언 https://rss.segye.com/segye_opinion.xml      
[뉴스]전국 https://rss.segye.com/segye_local.xml      
[뉴스]탐사이슈 https://rss.segye.com/segye_task_force.xml      
[뉴스]패n글 https://rss.segye.com/segye_family.xml      
[뉴스]루트 https://rss.segye.com/segye_root.xml      
[뉴스]펀치뉴스 https://rss.segye.com/segye_punchnews.xml      
[뉴스]포토뉴스 https://rss.segye.com/segye_photo.xml      
[뉴스]세계TV https://rss.segye.com/segye_segyeTV.xml      
[스포츠월드]최신기사 https://rss.sportsworldi.com/sw_recent.xml      
[스포츠월드]종합 https://rss.sportsworldi.com/sw_total.xml      
[스포츠월드]야구 https://rss.sportsworldi.com/sw_baseball.xml      
[스포츠월드]축구 https://rss.sportsworldi.com/sw_soccer.xml      
[스포츠월드]농구 https://rss.sportsworldi.com/sw_basketball.xml      
[스포츠월드]골프 https://rss.sportsworldi.com/sw_golf.xml      
[스포츠월드]연예 https://rss.sportsworldi.com/sw_entertainment.xml      
[스포츠월드]레저 https://rss.sportsworldi.com/sw_leisure.xml      
[스포츠월드]SW이슈 https://rss.sportsworldi.com/sw_opinion.xml      



## 매일경제         
         
헤드라인 https://file.mk.co.kr/news/rss/rss_30000001.xml      
문화ㆍ연예 https://file.mk.co.kr/news/rss/rss_30000023.xml      
실시간 속보 https://file.mk.co.kr/news/rss/rss_40300001.xml      
스포츠 https://file.mk.co.kr/news/rss/rss_50600001.xml      
경제 https://file.mk.co.kr/news/rss/rss_30100041.xml      
게임 https://file.mk.co.kr/news/rss/rss_50700001.xml      
정치 https://file.mk.co.kr/news/rss/rss_30200030.xml      
오피니언 https://file.mk.co.kr/news/rss/rss_30500041.xml      
사회 https://file.mk.co.kr/news/rss/rss_50400012.xml      
국제 https://file.mk.co.kr/news/rss/rss_30300018.xml      
기업ㆍ경영 https://file.mk.co.kr/news/rss/rss_50100032.xml      
증권 https://file.mk.co.kr/news/rss/rss_50200011.xml      
부동산 https://file.mk.co.kr/news/rss/rss_50300009.xml      
[특집기사]MBA https://file.mk.co.kr/news/rss/rss_40200124.xml      
[특집기사]머니 앤 리치스 https://file.mk.co.kr/news/rss/rss_40200003.xml      
영문뉴스 https://file.mk.co.kr/news/rss/rss_30800011.xml      
이코노미 https://file.mk.co.kr/news/rss/rss_50000001.xml      
시티라이프 https://file.mk.co.kr/news/rss/rss_60000007.xml      



## 한국아이닷컴         
         
[한국일보]전체기사 https://rss.hankooki.com/news/hk_main.xml      
[한국일보]정치 https://rss.hankooki.com/news/hk_politics.xml      
[한국일보]경제 https://rss.hankooki.com/news/hk_economy.xml      
[한국일보]사회 https://rss.hankooki.com/news/hk_society.xml      
[한국일보]문화 https://rss.hankooki.com/news/hk_culture.xml      
[한국일보]라이프 https://rss.hankooki.com/news/hk_life.xml      
[한국일보]국제 https://rss.hankooki.com/news/hk_world.xml      
[한국일보]IT https://rss.hankooki.com/news/hk_it_tech.xml      
[한국일보]피플 https://rss.hankooki.com/news/hk_people.xml      
[한국일보]스포츠 https://rss.hankooki.com/news/hk_sports.xml      
[한국일보]연예 https://rss.hankooki.com/news/hk_entv.xml      
[한국일보]사설/칼럼 https://rss.hankooki.com/news/hk_opinion.xml      
[한국일보]포토 https://rss.hankooki.com/news/hk_photoi.xml      
[한국일보]TV https://rss.hankooki.com/news/hk_tv.xml      
[스포츠한국]전체 https://rss.hankooki.com/sports/sp_main.xml      
[스포츠한국]스포츠 https://rss.hankooki.com/sports/sp_sports.xml      
[스포츠한국]연예 https://rss.hankooki.com/sports/sp_entv.xml      
[스포츠한국]라이프 https://rss.hankooki.com/sports/sp_life.xml      
[스포츠한국]n조이 https://rss.hankooki.com/sports/sp_enjoy.xml      
[서울경제]전체 https://rss.hankooki.com/economy/sk_main.xml      
[서울경제]경제 https://rss.hankooki.com/economy/sk_economy.xml      
[서울경제]증권 https://rss.hankooki.com/economy/sk_stock.xml      
[서울경제]부동산 https://rss.hankooki.com/economy/sk_estate.xml      
[서울경제]산업 https://rss.hankooki.com/economy/sk_industry.xml      
[서울경제]국제 https://rss.hankooki.com/economy/sk_world.xml      
[서울경제]정치 https://rss.hankooki.com/economy/sk_politics.xml      
[서울경제]사회 https://rss.hankooki.com/economy/sk_society.xml      
[서울경제]문화/스포츠- https://rss.hankooki.com/economy/sk_culture.xml      
[서울경제]오피니언 https://rss.hankooki.com/economy/sk_opinion.xml      
[소년한국]전체 https://rss.hankooki.com/kids/kd_main.xml      
[소년한국]어린이뉴스 https://rss.hankooki.com/kids/kd_news.xml      
[소년한국]배움터 https://rss.hankooki.com/kids/kd_learn.xml      
[소년한국]놀이터 https://rss.hankooki.com/kids/kd_play.xml      
[소년한국]우리들세상 https://rss.hankooki.com/kids/kd_childworld.xml      
[매거진]골프한국 https://rss.hankooki.com/magazine/gh_main.xml      
[매거진]골프매거진 https://rss.hankooki.com/magazine/gm_main.xml      
[매거진]파퓰러사이언스 https://rss.hankooki.com/magazine/pop_main.xml      
[매거진]주간한국 https://rss.hankooki.com/magazine/wk_main.xml      



## 미디어오늘         
         
전체기사 https://www.mediatoday.co.kr/rss/allArticle.xml      
인기기사 https://www.mediatoday.co.kr/rss/clickTop.xml      
정치 https://www.mediatoday.co.kr/rss/S1N1.xml      
경제•IT https://www.mediatoday.co.kr/rss/S1N2.xml      
사회 https://www.mediatoday.co.kr/rss/S1N3.xml      
문화•연예 https://www.mediatoday.co.kr/rss/S1N4.xml      
생활 https://www.mediatoday.co.kr/rss/S1N5.xml      
국제 https://www.mediatoday.co.kr/rss/S1N6.xml      
스포츠 https://www.mediatoday.co.kr/rss/S1N7.xml      
미디어 https://www.mediatoday.co.kr/rss/S1N8.xml      
오피니언 https://www.mediatoday.co.kr/rss/S1N9.xml      
만평 https://www.mediatoday.co.kr/rss/S1N10.xml      
미디어취업 https://www.mediatoday.co.kr/rss/S1N11.xml      
광고 https://www.mediatoday.co.kr/rss/S1N12.xml      
MIE센터 https://www.mediatoday.co.kr/rss/S1N13.xml      



## 한국경제         
         
경제/금융뉴스 https://rss.hankyung.com/economy.xml      
증권뉴스 https://rss.hankyung.com/stock.xml      
부동산뉴스 https://rss.hankyung.com/estate.xml      
산업뉴스 https://rss.hankyung.com/industry.xml      
국제뉴스 https://rss.hankyung.com/intl.xml      
정치/사회뉴스 https://rss.hankyung.com/politics.xml      
스포츠/문화뉴스 https://rss.hankyung.com/sports.xml      
사설/칼럼 https://rss.hankyung.com/column.xml      
취재기자X-File https://rss.hankyung.com/xfile.xml      
마켓리더스 https://rss.hankyung.com/leaders.xml      
재테크칼럼 https://rss.hankyung.com/ft.xml      
자동차칼럼 https://rss.hankyung.com/auto.xml      
골프칼럼 https://rss.hankyung.com/golf.xml      
커뮤니티칼럼 https://rss.hankyung.com/community.xml      
장군의아들 https://rss.hankyung.com/janggun.xml      
므흣한영어 https://rss.hankyung.com/english.xml      



## 파이낸셜뉴스         
         
[실시간]전체기사 https://www.fnnews.com/rss/fn_realnews_all.xml      
[실시간]증권 https://www.fnnews.com/rss/fn_realnews_stock.xml      
[실시간]금융 https://www.fnnews.com/rss/fn_realnews_finance.xml      
[실시간]부동산 https://www.fnnews.com/rss/fn_realnews_realestate.xml      
[실시간]산업 https://www.fnnews.com/rss/fn_realnews_industry.xml      
[실시간]경제 https://www.fnnews.com/rss/fn_realnews_economy.xml      
[실시간]IT/과학 https://www.fnnews.com/rss/fn_realnews_it.xml      
[실시간]생활경제 https://www.fnnews.com/rss/fn_realnews_circulation.xml      
[실시간]국제 https://www.fnnews.com/rss/fn_realnews_international.xml      
[실시간]정치 https://www.fnnews.com/rss/fn_realnews_politics.xml      
[실시간]지역경제/사회 https://www.fnnews.com/rss/fn_realnews_society.xml      
[실시간]문화 https://www.fnnews.com/rss/fn_realnews_culture.xml      
[실시간]스포츠 https://www.fnnews.com/rss/fn_realnews_sports.xml      
[실시간]교육 https://www.fnnews.com/rss/fn_realnews_edu.xml      
[실시간]피플 https://www.fnnews.com/rss/fn_realnews_people.xml      
[많이 본 뉴스]전체기사 https://www.fnnews.com/rss/fn_manyview_all.xml      
[많이 본 뉴스]증권 https://www.fnnews.com/rss/fn_manyview_stock.xml      
[많이 본 뉴스]금융 https://www.fnnews.com/rss/fn_manyview_finance.xml      
[많이 본 뉴스]부동산 https://www.fnnews.com/rss/fn_manyview_realestate.xml      
[많이 본 뉴스]산업 https://www.fnnews.com/rss/fn_manyview_industry.xml      
[많이 본 뉴스]경제 https://www.fnnews.com/rss/fn_manyview_economy.xml      
[많이 본 뉴스]IT/과학 https://www.fnnews.com/rss/fn_manyview_it.xml      
[많이 본 뉴스]생활경제 https://www.fnnews.com/rss/fn_manyview_circulation.xml      
[많이 본 뉴스]국제 https://www.fnnews.com/rss/fn_manyview_international.xml      
[많이 본 뉴스]정치 https://www.fnnews.com/rss/fn_manyview_politics.xml      
[많이 본 뉴스]지역경제/사회 https://www.fnnews.com/rss/fn_manyview_society.xml      
[많이 본 뉴스]문화 https://www.fnnews.com/rss/fn_manyview_culture.xml      
[많이 본 뉴스]스포츠 https://www.fnnews.com/rss/fn_manyview_sports.xml      
[많이 본 뉴스]교육 https://www.fnnews.com/rss/fn_manyview_edu.xml      
[많이 본 뉴스]피스 https://www.fnnews.com/rss/fn_manyview_people.xml      



## 헤럴드경제         
         
모든기사보기 https://biz.heraldm.com/rss/010000000000.xml      
[뉴스]전체보기 https://biz.heraldm.com/rss/010100000000.xml      
[뉴스]경제 https://biz.heraldm.com/rss/010104000000.xml      
[뉴스]정치 https://biz.heraldm.com/rss/010108000000.xml      
[뉴스]사회 https://biz.heraldm.com/rss/010109000000.xml      
[뉴스]기업 https://biz.heraldm.com/rss/010107000000.xml      
[뉴스]증권 https://biz.heraldm.com/rss/010106000000.xml      
[뉴스]국제 https://biz.heraldm.com/rss/010110000000.xml      
[뉴스]사설/컬럼 https://biz.heraldm.com/rss/010103000000.xml      
[생생코스닥]전체보기 https://biz.heraldm.com/rss/010200000000.xml      
[생생코스닥]종목포커스 https://biz.heraldm.com/rss/010202000000.xml      
[생생코스닥]CEO https://biz.heraldm.com/rss/010203000000.xml      
[생생코스닥]이슈 https://biz.heraldm.com/rss/010204000000.xml      
[생생코스닥]추천종목 https://biz.heraldm.com/rss/010205000000.xml      
[생생코스닥]코스닥일반 https://biz.heraldm.com/rss/010206000000.xml      
[생생코스닥]코스닥칼럼 https://biz.heraldm.com/rss/010207000000.xml      
[생생코스닥]비상장시세 https://biz.heraldm.com/rss/010208000000.xml      
[생생코스닥]KRX기업정보 https://biz.heraldm.com/rss/010209000000.xml      
[부동산]전체보기 https://biz.heraldm.com/rss/010300000000.xml      
[부동산]일반 https://biz.heraldm.com/rss/010301000000.xml      
[부동산]정책 https://biz.heraldm.com/rss/010303000000.xml      
[부동산]제테크 https://biz.heraldm.com/rss/010305000000.xml      
[부동산]시세/분양정보 https://biz.heraldm.com/rss/010306000000.xml      
[부동산]현장노트 https://biz.heraldm.com/rss/010308000000.xml      
[부동산]부동산TV https://biz.heraldm.com/rss/010309000000.xml      
[연예/스포츠]전체보기 https://biz.heraldm.com/rss/010400000000.xml      
[연예/스포츠]대중문화 https://biz.heraldm.com/rss/010403000000.xml      
[연예/스포츠]스타 https://biz.heraldm.com/rss/010404000000.xml      
[연예/스포츠]칼럼 https://biz.heraldm.com/rss/010409000000.xml      
[연예/스포츠]스포츠 https://biz.heraldm.com/rss/010410000000.xml      
[연예/스포츠]스타포토 https://biz.heraldm.com/rss/010405000000.xml      
[연예/스포츠]스타동영상 https://biz.heraldm.com/rss/010406000000.xml      
[라이프]전체보기 https://biz.heraldm.com/rss/010500000000.xml      
[라이프]자동차 https://biz.heraldm.com/rss/010501000000.xml      
[라이프]IT/전자/통신 https://biz.heraldm.com/rss/010502000000.xml      
[라이프]헬스 https://biz.heraldm.com/rss/010505000000.xml      
[라이프]스타일 https://biz.heraldm.com/rss/010506000000.xml      
[라이프]컬쳐 https://biz.heraldm.com/rss/010504000000.xml      
[라이프]여행/레져 https://biz.heraldm.com/rss/010503000000.xml      
[헤럴드생생]전체보기 https://biz.heraldm.com/rss/010600000000.xml      
[헤럴드생생]사람사는 이야기 https://biz.heraldm.com/rss/010601000000.xml      
[헤럴드생생]헤럴드 스쿨 https://biz.heraldm.com/rss/010602000000.xml      
[헤럴드생생]섹시IN https://biz.heraldm.com/rss/010604000000.xml      



## 국민일보         
         
전체기사 https://www.kukinews.com/rss/kmibRssAll.xml      
정치 https://www.kukinews.com/rss/kmibPolRss.xml      
경제 https://www.kukinews.com/rss/kmibEcoRss.xml      
사회 https://www.kukinews.com/rss/kmibSocRss.xml      
국제 https://www.kukinews.com/rss/kmibIntRss.xml      
스포츠 https://www.kukinews.com/rss/kmibSpoRss.xml      
문화 https://www.kukinews.com/rss/kmibCulRss.xml      
생활 https://www.kukinews.com/rss/kmibLifRss.xml      
사설/칼럼 https://www.kukinews.com/rss/kmibColRss.xml      
기독교계 소식 https://www.kukinews.com/rss/kmibChrRss.xml      
겨자씨 https://www.kukinews.com/rss/kmibSeedRss.xml      
역경의 열매 https://www.kukinews.com/rss/kmibAdvRss.xml      
가정예배 https://www.kukinews.com/rss/kmibWorRss.xml      



## 쿠키뉴스         
         
전체기사 https://www.kukinews.com/rss/kukiRssAll.xml      
사회 https://www.kukinews.com/rss/kukiSocRss.xml      
정치 https://www.kukinews.com/rss/kukiPolRss.xml      
지구촌 https://www.kukinews.com/rss/kukiIntRss.xml      
스포츠 https://www.kukinews.com/rss/kukiSpoRss.xml      
연예 https://www.kukinews.com/rss/kukiEntRss.xml      
문화 https://www.kukinews.com/rss/kukiCulRss.xml      
생활 https://www.kukinews.com/rss/kukiLifRss.xml      
톡톡 https://www.kukinews.com/rss/kukiTokRss.xml      
ONLY https://www.kukinews.com/rss/kukiOnyRss.xml      
쿠키방송 https://www.kukinews.com/rss/kukiBroRss.xml      
         
         
         
         
## 연합뉴스         
         
속보  https://www.yonhapnews.co.kr/RSS/sokbo.xml      
– 정치 · 북한  https://www.yonhapnews.co.kr/RSS/politics.xml      
– 경제 · IT  https://www.yonhapnews.co.kr/RSS/economy.xml      
– 증권  https://www.yonhapnews.co.kr/RSS/stock.xml      
– 사회  https://www.yonhapnews.co.kr/RSS/society.xml      
– 전국  https://www.yonhapnews.co.kr/RSS/province.xml      
– 세계  https://www.yonhapnews.co.kr/RSS/international.xml      
– 문화 · 예술  https://www.yonhapnews.co.kr/RSS/culture.xml      
– 스포츠  https://www.yonhapnews.co.kr/RSS/sports.xml      
– 연예  https://www.yonhapnews.co.kr/RSS/entertainment.xml      
         
         
         
         
## 시티뉴스         
         
전체기사 https://www.clubcity.kr/rss/allArticle.xml      
인기기사 https://www.clubcity.kr/rss/clickTop.xml      
스포츠 https://www.clubcity.kr/rss/S1N6.xml      
라이프 https://www.clubcity.kr/rss/S1N7.xml      
블로그뉴스 https://www.clubcity.kr/rss/S1N8.xml      
블러그이슈 https://www.clubcity.kr/rss/S1N10.xml      
엔터테인먼트 https://www.clubcity.kr/rss/S1N11.xml      
이전사이트섹션 https://www.clubcity.kr/rss/S1N12.xml      
연합뉴스 https://www.clubcity.kr/rss/S1N13.xml      
포토뉴스 https://www.clubcity.kr/rss/S1N14.xml      
칼럼 https://www.clubcity.kr/rss/S1N15.xml      
프라자 https://www.clubcity.kr/rss/S1N16.xml      
카툰 https://www.clubcity.kr/rss/S1N17.xml      
좋은농산물 탐구생활 https://www.clubcity.kr/rss/S1N19.xml      
디지털/게임 https://www.clubcity.kr/rss/S1N23.xml      
머니/창업 https://www.clubcity.kr/rss/S1N24.xml      
건강 https://www.clubcity.kr/rss/S1N25.xml      
씨네뉴스 https://www.clubcity.kr/rss/S1N26.xml      
뉴스 https://www.clubcity.kr/rss/S1N27.xml      
모바일 이벤트 https://www.clubcity.kr/rss/S1N28.xml      
시티챠트 https://www.clubcity.kr/rss/S1N29.xml      
시티특종 https://www.clubcity.kr/rss/S1N30.xml      
         
         
         
         
## 데이터넷         
         
전체기사 https://www.datanet.co.kr/rss/allArticle.xml      
인기기사 https://www.datanet.co.kr/rss/clickTop.xml      
뉴스 https://www.datanet.co.kr/rss/S1N1.xml      
인물&기업 https://www.datanet.co.kr/rss/S1N2.xml      
기획특집 https://www.datanet.co.kr/rss/S1N3.xml      
테크가이드 https://www.datanet.co.kr/rss/S1N4.xml      
제품가이드 https://www.datanet.co.kr/rss/S1N5.xml      
NETWORK TIMES https://www.datanet.co.kr/rss/S1N6.xml      
         
                  
         
## K모바일         
         
전체뉴스 https://www.kmobile.co.kr/rss/all    
IT산업 https://www.kmobile.co.kr/rss/it    
통신방송 https://www.kmobile.co.kr/rss/comm    
인터넷 https://www.kmobile.co.kr/rss/internet    
콘텐츠 https://www.kmobile.co.kr/rss/contents    
디바이스 https://www.kmobile.co.kr/rss/device    
부품 https://www.kmobile.co.kr/rss/chip    
소프트웨어 https://www.kmobile.co.kr/rss/software    
재테크 https://www.kmobile.co.kr/rss/ftech    
직장인 https://www.kmobile.co.kr/rss/jobman    
라이프 https://www.kmobile.co.kr/rss/life    
블로고스피어 https://www.kmobile.co.kr/rss/blog    
         
         
         
         
## 디지털데일리         
         
IT정책  https://www.ddaily.co.kr/DATA/rss/ddaily_rss_itpolicy.xml      
통신·방송  https://www.ddaily.co.kr/DATA/rss/ddaily_rss_broadcast.xml      
e비즈·솔루션  https://www.ddaily.co.kr/DATA/rss/ddaily_rss_ebiz.xml      
보안  https://www.ddaily.co.kr/DATA/rss/ddaily_rss_security.xml      
콘텐츠  https://www.ddaily.co.kr/DATA/rss/ddaily_rss_contents.xml      
기업문화  https://www.ddaily.co.kr/DATA/rss/ddaily_rss_culture.xml      
산업  https://www.ddaily.co.kr/DATA/rss/ddaily_rss_industry.xml      
         
         
         
         
## 에이빙뉴스         
         
모바일/통신 https://www.aving.net/rss/mobile.xml      
컴퓨팅 https://www.aving.net/rss/computing.xml      
가전 https://www.aving.net/rss/homeappliance.xml      
라이프 https://www.aving.net/rss/life.xml      
하우징 https://www.aving.net/rss/housing.xml      
자동차 https://www.aving.net/rss/motor.xml      
이색상품 https://www.aving.net/rss/misc.xml      
업계동향 https://www.aving.net/rss/industry.xml      
영상음향 https://www.aving.net/rss/avpa.xml      
여행 https://www.aving.net/rss/.xml      
에이빙걸 https://www.aving.net/rss/.xml      
게임 https://www.aving.net/rss/game.xml      
에이빙걸 https://www.aving.net/rss/.xml      
뉴스後뉴스 https://www.aving.net/rss/.xml      
         
         
         
         
## 리뷰스타         
         
전체기사 https://www.reviewstar.net/rss/allArticle.xml      
인기기사 https://www.reviewstar.net/rss/clickTop.xml      
방송연예 https://www.reviewstar.net/rss/S1N1.xml      
스타뉴스 https://www.reviewstar.net/rss/S1N2.xml      
포토뉴스 https://www.reviewstar.net/rss/S1N3.xml      
생활문화 https://www.reviewstar.net/rss/S1N4.xml      
영문뉴스 https://www.reviewstar.net/rss/S1N5.xml      
         
         
         
         
## 오늘의 뉴스         
         
전체기사 https://www.today-news.co.kr/rss/allArticle.xml      
인기기사 https://www.today-news.co.kr/rss/clickTop.xml      
오늘의뉴스 https://www.today-news.co.kr/rss/S1N1.xml      
건강뉴스 https://www.today-news.co.kr/rss/S1N2.xml      
오픈블로그 https://www.today-news.co.kr/rss/S1N3.xml      
보도자료 https://www.today-news.co.kr/rss/S1N4.xml      
연예가뉴스 https://www.today-news.co.kr/rss/S1N5.xml      
오늘의만화 https://www.today-news.co.kr/rss/S1N6.xml      
         
         
         
         
## 한국방송뉴스         
         
전체기사 https://ikbn.co.kr/repository/rss/rss_total.xml      
뉴스종합 https://ikbn.co.kr/repository/rss/rss_1.xml      
오피니언 https://ikbn.co.kr/repository/rss/rss_2.xml      
멀티미디어 https://ikbn.co.kr/repository/rss/rss_3.xml      
전국뉴스 https://ikbn.co.kr/repository/rss/rss_4.xml      
전남지역 https://ikbn.co.kr/repository/rss/rss_5.xml      
정책탱크 https://ikbn.co.kr/repository/rss/rss_6.xml      
섹션 https://ikbn.co.kr/repository/rss/rss_7.xml      
사회 https://ikbn.co.kr/repository/rss/rss_1_1.xml      
정치 https://ikbn.co.kr/repository/rss/rss_1_2.xml      
경제 https://ikbn.co.kr/repository/rss/rss_1_3.xml      
문화 https://ikbn.co.kr/repository/rss/rss_1_4.xml      
연예 https://ikbn.co.kr/repository/rss/rss_1_5.xml      
스포츠 https://ikbn.co.kr/repository/rss/rss_1_6.xml      
과학 https://ikbn.co.kr/repository/rss/rss_1_7.xml      
생활·건강 https://ikbn.co.kr/repository/rss/rss_1_8.xml      
지역 https://ikbn.co.kr/repository/rss/rss_1_75.xml      
포토 https://ikbn.co.kr/repository/rss/rss_1_9.xml      
사건·사고 https://ikbn.co.kr/repository/rss/rss_1_10.xml      
해외 https://ikbn.co.kr/repository/rss/rss_1_11.xml      
카메라고발 https://ikbn.co.kr/repository/rss/rss_1_12.xml      
         
         
         
         
## 탑라이더         
         
전체기사 https://www.top-rider.com/rss/allArticle.xml      
인기기사 https://www.top-rider.com/rss/clickTop.xml      
뉴스 https://www.top-rider.com/rss/S1N1.xml      
펀오토 https://www.top-rider.com/rss/S1N4.xml      
포토/영상 https://www.top-rider.com/rss/S1N5.xml      
오토칼럼 https://www.top-rider.com/rss/S1N7.xml      
시승기 https://www.top-rider.com/rss/S1N8.xml      
사용기 https://www.top-rider.com/rss/S1N9.xml      
         
         
         
         
## 뉴스포스트         
         
전체기사 https://www.newspost.kr/rss/allArticle.xml      
인기기사 https://www.newspost.kr/rss/clickTop.xml      
정치 https://www.newspost.kr/rss/S1N1.xml      
경제 https://www.newspost.kr/rss/S1N2.xml      
사회 https://www.newspost.kr/rss/S1N3.xml      
문화 https://www.newspost.kr/rss/S1N4.xml      
기획 https://www.newspost.kr/rss/S1N5.xml      
스타클릭 https://www.newspost.kr/rss/S1N6.xml      
         
         
         
         
## 뉴스데일리         
         
전체기사 https://www.newsdaily.kr/rss/allArticle.xml      
인기기사 https://www.newsdaily.kr/rss/clickTop.xml      
종합뉴스 https://www.newsdaily.kr/rss/S1N1.xml      
기획&특집 https://www.newsdaily.kr/rss/S1N2.xml      
지역 https://www.newsdaily.kr/rss/S1N4.xml      
뉴스플러스 https://www.newsdaily.kr/rss/S1N30.xml      
시사기획 https://www.newsdaily.kr/rss/S1N32.xml      
사회 https://www.newsdaily.kr/rss/S1N38.xml      
문화 https://www.newsdaily.kr/rss/S1N39.xml      
국제 https://www.newsdaily.kr/rss/S1N40.xml      
연예·스포츠 https://www.newsdaily.kr/rss/S1N46.xml      
봉사·나눔 https://www.newsdaily.kr/rss/S1N47.xml      
경제 https://www.newsdaily.kr/rss/S1N49.xml      
부동산 https://www.newsdaily.kr/rss/S1N50.xml      
정치 https://www.newsdaily.kr/rss/S1N51.xml      
         
         
         
         
## 뉴스위드         
         
전체기사 https://www.newswith.co.kr/rss/allArticle.xml      
인기기사 https://www.newswith.co.kr/rss/clickTop.xml      
정치/행정 https://www.newswith.co.kr/rss/S1N1.xml      
경제 https://www.newswith.co.kr/rss/S1N2.xml      
사회 https://www.newswith.co.kr/rss/S1N3.xml      
교육 https://www.newswith.co.kr/rss/S1N4.xml      
문화생활 https://www.newswith.co.kr/rss/S1N5.xml      
스포츠/연예 https://www.newswith.co.kr/rss/S1N6.xml      
With 충청 https://www.newswith.co.kr/rss/S1N7.xml      
Hot issue https://www.newswith.co.kr/rss/S1N8.xml      
생생칼럼 https://www.newswith.co.kr/rss/S1N9.xml      
With people https://www.newswith.co.kr/rss/S1N10.xml      
포토영상 https://www.newswith.co.kr/rss/S1N11.xml      
         
         
         
         
## 컨슈머타임스         
         
전체기사 https://www.cstimes.com/rss/allArticle.xml      
인기기사 https://www.cstimes.com/rss/clickTop.xml      
뉴스 https://www.cstimes.com/rss/S1N1.xml      
파이낸셜컨슈머 https://www.cstimes.com/rss/S1N3.xml      
컨슈머기자리뷰 https://www.cstimes.com/rss/S1N4.xml      
오피니언 https://www.cstimes.com/rss/S1N5.xml      
비타민CS뉴스 https://www.cstimes.com/rss/S1N7.xml      
컨슈머플러스 https://www.cstimes.com/rss/S1N8.xml      
소비자고발영상 https://www.cstimes.com/rss/S1N9.xml      
동정 https://www.cstimes.com/rss/S1N10.xml      
스포츠 https://www.cstimes.com/rss/S1N11.xml      
연예 https://www.cstimes.com/rss/S1N12.xml      
photo fashion https://www.cstimes.com/rss/S1N13.xml      
photo star https://www.cstimes.com/rss/S1N14.xml      
컨슈머타임스 선정 히트상품 https://www.cstimes.com/rss/S1N15.xml      
소비자 태도지수 https://www.cstimes.com/rss/S1N16.xml      
나눔로또 금주 당첨번호 https://www.cstimes.com/rss/S1N17.xml      
소비자고발24시 https://www.cstimes.com/rss/S1N18.xml      
소비자피해Q&A https://www.cstimes.com/rss/S1N19.xml      
황당뉴스 https://www.cstimes.com/rss/S1N20.xml      
연합뉴스 https://www.cstimes.com/rss/S1N21.xml      
         
         
         
         
## 코리아뉴스방송         
         
전체기사 https://www.koreanewstv.com/rss/allArticle.xml      
인기기사 https://www.koreanewstv.com/rss/clickTop.xml      
정치·북한 https://www.koreanewstv.com/rss/S1N1.xml      
경제·IT https://www.koreanewstv.com/rss/S1N2.xml      
정부부처 https://www.koreanewstv.com/rss/S1N3.xml      
사회 https://www.koreanewstv.com/rss/S1N4.xml      
전국 https://www.koreanewstv.com/rss/S1N5.xml      
세계 https://www.koreanewstv.com/rss/S1N6.xml      
문화 https://www.koreanewstv.com/rss/S1N7.xml      
스포츠 https://www.koreanewstv.com/rss/S1N8.xml      
연예 https://www.koreanewstv.com/rss/S1N9.xml      
핫이슈 https://www.koreanewstv.com/rss/S1N10.xml      
보도자료 https://www.koreanewstv.com/rss/S1N11.xml      
인사·부고·동정 https://www.koreanewstv.com/rss/S1N12.xml      
포토·그래픽 https://www.koreanewstv.com/rss/S1N13.xml      
전국메디컬 https://www.koreanewstv.com/rss/S1N14.xml      
블로그 https://www.koreanewstv.com/rss/S1N15.xml      
만화 https://www.koreanewstv.com/rss/S1N16.xml      
논평 https://www.koreanewstv.com/rss/S1N17.xml      
사설 https://www.koreanewstv.com/rss/S1N18.xml      
코리아라이트 https://www.koreanewstv.com/rss/S1N19.xml      
기자수첩 https://www.koreanewstv.com/rss/S1N20.xml      
독자투고칼럼 https://www.koreanewstv.com/rss/S1N21.xml      
대선후보기사 https://www.koreanewstv.com/rss/S1N22.xml      
정치칼럼 https://www.koreanewstv.com/rss/S1N23.xml      
의료칼럼 https://www.koreanewstv.com/rss/S1N24.xml      
한의학칼럼 https://www.koreanewstv.com/rss/S1N25.xml      
화재의인물뉴스 https://www.koreanewstv.com/rss/S1N26.xml      
특별기획취재 https://www.koreanewstv.com/rss/S1N27.xml      
지금정치권에선 https://www.koreanewstv.com/rss/S1N28.xml      
지금세계는 https://www.koreanewstv.com/rss/S1N29.xml      
전국지자체뉴스 https://www.koreanewstv.com/rss/S1N30.xml      
건강닥터칼럼 https://www.koreanewstv.com/rss/S1N31.xml      
CEO https://www.koreanewstv.com/rss/S1N32.xml      
오늘의톱뉴스 https://www.koreanewstv.com/rss/S1N33.xml      
방송속보 https://www.koreanewstv.com/rss/S1N34.xml      
         
         
         
         
## 엔터포츠         
         
전체기사 https://www.enponews.com/rss/allArticle.xml      
인기기사 https://www.enponews.com/rss/clickTop.xml      
Sports https://www.enponews.com/rss/S1N1.xml      
Entertainment https://www.enponews.com/rss/S1N2.xml      
Photo https://www.enponews.com/rss/S1N3.xml      
축구 https://www.enponews.com/rss/S2N1.xml      
야구 https://www.enponews.com/rss/S2N2.xml      
농구·배구 https://www.enponews.com/rss/S2N3.xml      
스포츠일반 https://www.enponews.com/rss/S2N4.xml      
스포츠 https://www.enponews.com/rss/S2N5.xml      
엔터테인먼트 https://www.enponews.com/rss/S2N6.xml      
         
         
         
         
## 에버뉴스         
         
전체기사 https://www.evernews.co.kr/rss/allArticle.xml      
인기기사 https://www.evernews.co.kr/rss/clickTop.xml      
에버뉴스 https://www.evernews.co.kr/rss/S1N2.xml      
포토 https://www.evernews.co.kr/rss/S1N4.xml      
에버 TV https://www.evernews.co.kr/rss/S1N5.xml      
연예소식 https://www.evernews.co.kr/rss/S1N6.xml      
법원 · 검찰 https://www.evernews.co.kr/rss/S1N8.xml      
지역소식 https://www.evernews.co.kr/rss/S1N9.xml      
생활정보 https://www.evernews.co.kr/rss/S1N10.xml      
인터뷰·오피니언 https://www.evernews.co.kr/rss/S1N11.xml      
행사 · 축제 https://www.evernews.co.kr/rss/S1N12.xml      
         
         
         
         
## 주간포커스         
         
전체기사 https://www.focuscolorado.net/rss/allArticle.xml      
인기기사 https://www.focuscolorado.net/rss/clickTop.xml      
콜로라도 https://www.focuscolorado.net/rss/S1N1.xml      
미국뉴스 https://www.focuscolorado.net/rss/S1N2.xml      
한국뉴스 https://www.focuscolorado.net/rss/S1N3.xml      
월드뉴스 https://www.focuscolorado.net/rss/S1N4.xml      
여행 https://www.focuscolorado.net/rss/S1N5.xml      
생활ㆍ상식 https://www.focuscolorado.net/rss/S1N6.xml      
연예ㆍ스포츠 https://www.focuscolorado.net/rss/S1N7.xml      
유머 https://www.focuscolorado.net/rss/S1N8.xml      
         
         
         
         
## 라이프업         
         
전체기사 https://www.laup.co.kr/rss/rss.php    
-뉴스 https://www.laup.co.kr/rss/rss.php?mv_data=cGFydF9pZHglM0Qx    
정치 https://www.laup.co.kr/rss/rss.php?mv_data=cGFydF9pZHglM0Qy    
생활경제 https://www.laup.co.kr/rss/rss.php?mv_data=cGFydF9pZHglM0Qz    
부동산 https://www.laup.co.kr/rss/rss.php?mv_data=cGFydF9pZHglM0Q0    
매거진UP https://www.laup.co.kr/rss/rss.php?mv_data=cGFydF9pZHglM0Q1    
자동차 https://www.laup.co.kr/rss/rss.php?mv_data=cGFydF9pZHglM0Q2    
IT/게임 https://www.laup.co.kr/rss/rss.php?mv_data=cGFydF9pZHglM0Q1OQ==    
         
         
         
         
## ZDNet Korea         
         
전체기사 https://www.zdnet.co.kr/Include2/ZDNetKorea_News.xml      
방송/통신 https://www.zdnet.co.kr/Include2/NewsSection0010.xml      
컴퓨팅 https://www.zdnet.co.kr/Include2/NewsSection0020.xml      
홈&모바일 https://www.zdnet.co.kr/Include2/NewsSection0030.xml      
인터넷 https://www.zdnet.co.kr/Include2/NewsSection0040.xml      
반도체 https://www.zdnet.co.kr/Include2/NewsSection0050.xml      
게임 https://www.zdnet.co.kr/Include2/NewsSection0060.xml      
메가뉴스TV https://www.zdnet.co.kr/Include2/MegaNewsTv.xml      
https://m.zdnet.co.kr/news_view.asp?artice_id=20110708155255    
https://www.zdnet.co.kr/news/news_view.asp?artice_id=20110708155255    
         
         
         
         
## 다음뉴스         
         
종합 https://media.daum.net/rss/today/primary/all/rss2.xml      
연예 https://media.daum.net/rss/today/primary/entertain/rss2.xml      
스포츠 https://media.daum.net/rss/today/primary/sports/rss2.xml      
사회 https://media.daum.net/rss/part/primary/society/rss2.xml      
정치 https://media.daum.net/rss/part/primary/politics/rss2.xml      
경제 https://media.daum.net/rss/part/primary/economic/rss2.xml      
국제 https://media.daum.net/rss/part/primary/foreign/rss2.xml      
문화·생활 https://media.daum.net/rss/part/primary/culture/rss2.xml      
연예 https://media.daum.net/rss/part/primary/entertain/rss2.xml      
IT·과학 https://media.daum.net/rss/part/primary/digital/rss2.xml      
오늘의 포토갤러리 https://media.daum.net/rss/today/photo/rss2.xml      
오늘의 TV뉴스 https://media.daum.net/rss/today/tvnews/rss2.xml      
         
         
         
         
## 파란뉴스         
         
[많이본뉴스]종합 https://media.paran.com/rss/rss.kth?view=10    
[많이본뉴스]연예 https://media.paran.com/rss/rss.kth?view=15    
[많이본뉴스]스포츠 https://media.paran.com/rss/rss.kth?view=16    
[많이본뉴스]추천베스트 https://media.paran.com/rss/rss.kth?view=18    
[많이본뉴스]리플베스트 https://media.paran.com/rss/rss.kth?view=20    
정치 https://media.paran.com/rss/rss.kth?view=2    
사회 https://media.paran.com/rss/rss.kth?view=4    
경제IT https://media.paran.com/rss/rss.kth?view=3    
연예 https://media.paran.com/rss/rss.kth?view=5    
스포츠 https://media.paran.com/rss/rss.kth?view=6    
IT https://media.paran.com/rss/rss.kth?view=9    
생활/문화 https://media.paran.com/rss/rss.kth?view=7    
세계 https://media.paran.com/rss/rss.kth?view=8    
칼럼 https://media.paran.com/rss/rss.kth?view=11    
         
         
         
         
## 구글뉴스         
         
[전체기사]주요뉴스 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&output=rss     
[전체기사]인기뉴스 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=po&output=rss     
[전체기사]정치 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=p&output=rss     
[전체기사]경제 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=b&output=rss     
[전체기사]사회 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=y&output=rss     
[전체기사]문화/생활 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=l&output=rss     
[전체기사]국제 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=w&output=rss     
[전체기사]정보과학 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=t&output=rss     
[전체기사]연예 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=e&output=rss     
[전체기사]스포츠 https://news.google.co.kr/news?pz=1&cf=all&ned=kr&hl=ko&topic=s&output=rss     
[헤드라인]주요뉴스 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&output=rss     
[헤드라인]인기뉴스 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=po&output=rss     
[헤드라인]정치 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=p&output=rss     
[헤드라인]경제 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=b&output=rss     
[헤드라인]사회 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=y&output=rss     
[헤드라인]문화/생활 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=l&output=rss     
[헤드라인]국제 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=w&output=rss     
[헤드라인]정보과학 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=t&output=rss     
[헤드라인]연예 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=e&output=rss     
[헤드라인]스포츠 https://news.google.co.kr/news?pz=1&hdlOnly=1&cf=all&ned=kr&hl=ko&topic=s&output=rss     
         
         
		 
         
         
## 경인일보         
         
전체기사 https://www.kyeongin.com/rss/allArticle.xml          
인기기사 https://www.kyeongin.com/rss/clickTop.xml    
정치 https://www.kyeongin.com/rss/S1N1.xml    
경제 https://www.kyeongin.com/rss/S1N2.xml    
사회 https://www.kyeongin.com/rss/S1N3.xml    
지역종합 https://www.kyeongin.com/rss/S1N4.xml    
문화 https://www.kyeongin.com/rss/S1N5.xml    
연예 https://www.kyeongin.com/rss/S1N6.xml    
스포츠 https://www.kyeongin.com/rss/S1N7.xml    
국제 https://www.kyeongin.com/rss/S1N8.xml    
기획(경기) https://www.kyeongin.com/rss/S1N9.xml    
기획(인천) https://www.kyeongin.com/rss/S1N24.xml    
미분류 https://www.kyeongin.com/rss/S1N12.xml    
사람들 https://www.kyeongin.com/rss/S1N13.xml      
포토존 https://www.kyeongin.com/rss/S1N16.xml      
사설 https://www.kyeongin.com/rss/S1N17.xml      
칼럼 https://www.kyeongin.com/rss/S1N18.xml      
사고 https://www.kyeongin.com/rss/S1N19.xml      
인천 https://www.kyeongin.com/rss/S1N21.xml      
오피니언 https://www.kyeongin.com/rss/S1N25.xml      
휴플러스 https://www.kyeongin.com/rss/S1N26.xml      
보도자료 https://www.kyeongin.com/rss/S1N27.xml      
특집 https://www.kyeongin.com/rss/S1N28.xml      
        
		
        
		
## 중부매일        
		
전체기사 https://www.jbnews.com/rss/allArticle.xml      
인기기사 https://www.jbnews.com/rss/clickTop.xml      
정치 https://www.jbnews.com/rss/S1N1.xml      
경제 https://www.jbnews.com/rss/S1N2.xml      
사회 https://www.jbnews.com/rss/S1N3.xml      
문화 https://www.jbnews.com/rss/S1N4.xml      
충북 https://www.jbnews.com/rss/S1N5.xml      
대전충남 https://www.jbnews.com/rss/S1N6.xml      
오피니언 https://www.jbnews.com/rss/S1N7.xml      
사람들 https://www.jbnews.com/rss/S1N8.xml      
포토 https://www.jbnews.com/rss/S1N9.xml      
스포츠/연예 https://www.jbnews.com/rss/S1N10.xml      
라이프 https://www.jbnews.com/rss/S1N11.xml      
기획특집 https://www.jbnews.com/rss/S1N12.xml      
시민기자 https://www.jbnews.com/rss/S1N13.xml      
미분류 섹션 https://www.jbnews.com/rss/S1N14.xml      
임시 https://www.jbnews.com/rss/S1N15.xml      
국제 https://www.jbnews.com/rss/S1N16.xml      
전국 https://www.jbnews.com/rss/S1N18.xml      
블로그뉴스 https://www.jbnews.com/rss/S1N19.xml      
        
		
        
		
## 한국기자협회        
		
전체기사 https://www.journalist.or.kr/rss/allArticle.xml      
인기기사 https://www.journalist.or.kr/rss/clickTop.xml      
미디어 https://www.journalist.or.kr/rss/S1N2.xml      
지역 https://www.journalist.or.kr/rss/S1N6.xml      
포토 https://www.journalist.or.kr/rss/S1N8.xml      
International https://www.journalist.or.kr/rss/S1N10.xml      
지난기사 https://www.journalist.or.kr/rss/S1N11.xml      
단신 https://www.journalist.or.kr/rss/S1N12.xml      
인터뷰 https://www.journalist.or.kr/rss/S1N16.xml      
만평 https://www.journalist.or.kr/rss/S1N19.xml      
기자상 https://www.journalist.or.kr/rss/S1N20.xml      
인사·부음 https://www.journalist.or.kr/rss/S1N21.xml      
기획·특집 https://www.journalist.or.kr/rss/S1N22.xml      
오피니언 https://www.journalist.or.kr/rss/S1N23.xml      
기자수첩 https://www.journalist.or.kr/rss/S1N24.xml      
비평·해설 https://www.journalist.or.kr/rss/S1N25.xml      
신간안내 https://www.journalist.or.kr/rss/S1N26.xml      
        
		
        
		
## 뉴스웨이        
		
전체기사 https://www.newsway.kr/rss/allArticle.xml      
인기기사 https://www.newsway.kr/rss/clickTop.xml      
정치 https://www.newsway.kr/rss/S1N1.xml      
경제 https://www.newsway.kr/rss/S1N2.xml      
사회 https://www.newsway.kr/rss/S1N3.xml      
문화 https://www.newsway.kr/rss/S1N4.xml      
국제/통일 https://www.newsway.kr/rss/S1N6.xml      
스포츠/연예 https://www.newsway.kr/rss/S1N8.xml      
칼럼 https://www.newsway.kr/rss/S1N10.xml      
생활경제 https://www.newsway.kr/rss/S1N11.xml      
의료/건강 https://www.newsway.kr/rss/S1N12.xml      
스포츠한국 https://www.newsway.kr/rss/S1N13.xml      
시민광장 https://www.newsway.kr/rss/S1N14.xml      
카툰 https://www.newsway.kr/rss/S1N15.xml      
기자수첩 https://www.newsway.kr/rss/S1N18.xml      
사람과 사람 https://www.newsway.kr/rss/S1N19.xml      
레이싱모델 https://www.newsway.kr/rss/S1N20.xml      
금주의 S라인 https://www.newsway.kr/rss/S1N21.xml      
스타화보 https://www.newsway.kr/rss/S1N24.xml      
스포츠 https://www.newsway.kr/rss/S1N26.xml      
연예 https://www.newsway.kr/rss/S1N27.xml      
포토뉴스 https://www.newsway.kr/rss/S1N28.xml      
서울·경기 https://www.newsway.kr/rss/S1N29.xml      
부산·경남 https://www.newsway.kr/rss/S1N30.xml      
광주·전남 https://www.newsway.kr/rss/S1N31.xml      
시사 https://www.newsway.kr/rss/S1N32.xml      
특별기획 https://www.newsway.kr/rss/S1N33.xml      
칼럼 https://www.newsway.kr/rss/S1N34.xml      
행사자료 https://www.newsway.kr/rss/S1N35.xml      
fx뉴스 https://www.newsway.kr/rss/S1N36.xml      
6.2선거특집 https://www.newsway.kr/rss/S1N37.xml      
대한인라인롤러연맹 경기자료 https://www.newsway.kr/rss/S1N38.xml      
뉴스웨이호남취재본부 https://www.newsway.kr/rss/S1N39.xml      
여행정보 https://www.newsway.kr/rss/S1N40.xml      
경남취재본부 https://www.newsway.kr/rss/S1N41.xml      
China Dolls https://www.newsway.kr/rss/S1N42.xml      
연예계 현장 https://www.newsway.kr/rss/S1N43.xml      
        
		
        
		
## 스타엔뉴스        
		
스타 https://file.starnow.co.kr/ex/rss/starN_2.xml      
방송 https://file.starnow.co.kr/ex/rss/starN_1.xml      
영화 https://file.starnow.co.kr/ex/rss/starN_4.xml      
뮤직 https://file.starnow.co.kr/ex/rss/starN_3.xml      
공연 https://file.starnow.co.kr/ex/rss/starN_5.xml      
스타일 https://file.starnow.co.kr/ex/rss/starN_9.xml      
스포츠 https://file.starnow.co.kr/ex/rss/starN_21.xml      
        
		
        
		
## 톱스타뉴스        
		
전체 https://www.topstarnews.net/n_news/rss/rss.php    
K-TV https://www.topstarnews.net/n_news/rss/rss.php?code=netfu_44711_17340&s_code=netfu_79101_40077    
K-POP https://www.topstarnews.net/n_news/rss/rss.php?code=netfu_44711_17340&s_code=netfu_95234_19777    
        
		
        
		
## 연예남녀        
		
전체기사 https://www.lovemf.net/rss/allArticle.xml      
인기기사 https://www.lovemf.net/rss/clickTop.xml      
연애뉴스 https://www.lovemf.net/rss/S1N1.xml      
연애가산책 https://www.lovemf.net/rss/S1N2.xml      
연애남녀 https://www.lovemf.net/rss/S1N3.xml      
독자광장 https://www.lovemf.net/rss/S1N5.xml      
연애와 성 https://www.lovemf.net/rss/S1N6.xml      
연애리포트 https://www.lovemf.net/rss/S1N8.xml      
유형별 매칭컨설팅 https://www.lovemf.net/rss/S1N9.xml      
임시보관함 https://www.lovemf.net/rss/S1N10.xml      
매칭컨설팅 https://www.lovemf.net/rss/S1N11.xml      
        
		
        
		
## 100인닷컴        
		
전체기사 https://www.100in.com/rss/allArticle.xml      
인기기사 https://www.100in.com/rss/clickTop.xml      
정치 https://www.100in.com/rss/S1N1.xml      
사람 https://www.100in.com/rss/S1N2.xml      
맛집 https://www.100in.com/rss/S1N3.xml      
동네소식 https://www.100in.com/rss/S1N4.xml      
미디어 https://www.100in.com/rss/S1N5.xml      
문화 https://www.100in.com/rss/S1N6.xml      
칼럼 https://www.100in.com/rss/S1N7.xml      
기고 https://www.100in.com/rss/S1N8.xml      
일상·생활 https://www.100in.com/rss/S1N9.xml      
        
		
        
		
## 르몽드 디플로마티크        
		
전체기사 https://www.ilemonde.com/rss/allArticle.xml      
인기기사 https://www.ilemonde.com/rss/clickTop.xml      
알림기사 https://www.ilemonde.com/rss/S1N28.xml      
월별목차 https://www.ilemonde.com/rss/S1N29.xml      
사회 https://www.ilemonde.com/rss/S1N30.xml      
지구촌/한반도 https://www.ilemonde.com/rss/S1N31.xml      
정치 https://www.ilemonde.com/rss/S1N32.xml      
경제 https://www.ilemonde.com/rss/S1N33.xml      
문화 https://www.ilemonde.com/rss/S1N34.xml      
인터뷰/칼럼 https://www.ilemonde.com/rss/S1N35.xml      
출판/서평/여행 https://www.ilemonde.com/rss/S1N36.xml      
임시메인(테스트) https://www.ilemonde.com/rss/S1N37.xml      
철학까페 https://www.ilemonde.com/rss/S1N38.xml      
기획/특집 https://www.ilemonde.com/rss/S1N39.xml      
임시메인 https://www.ilemonde.com/rss/S1N40.xml      
        
		
        
		
## 엑스포저널        
		
전체기사 https://www.expojr.com/rss/allArticle.xml      
인기기사 https://www.expojr.com/rss/clickTop.xml      
산업전시회 https://www.expojr.com/rss/S1N1.xml      
EXPO기업/제품 https://www.expojr.com/rss/S1N2.xml      
MICE/세미나 https://www.expojr.com/rss/S1N3.xml      
산업뉴스 https://www.expojr.com/rss/S1N5.xml      
창업/마케팅 https://www.expojr.com/rss/S1N6.xml      
축제/문화/연예 https://www.expojr.com/rss/S1N7.xml      
        
		
        
		
## 미디어데일리        
		
전체기사 https://www.mediadaily.co.kr/rss/allArticle.xml      
인기기사 https://www.mediadaily.co.kr/rss/clickTop.xml      
뉴스비평 https://www.mediadaily.co.kr/rss/S1N1.xml      
방송비평 https://www.mediadaily.co.kr/rss/S1N2.xml      
방송/연예 https://www.mediadaily.co.kr/rss/S1N3.xml      
산업/과학 https://www.mediadaily.co.kr/rss/S1N4.xml      
피플/문화 https://www.mediadaily.co.kr/rss/S1N5.xml      
오피니언 https://www.mediadaily.co.kr/rss/S1N6.xml      
시민뉴스 https://www.mediadaily.co.kr/rss/S1N7.xml      
        
		
        
		
## 허핑턴포스트        
		
피드 https://www.huffingtonpost.kr/feeds/verticals/korea/index.xml      
블로그 https://www.huffingtonpost.kr/feeds/verticals/korea/blog.xml      
뉴스 https://www.huffingtonpost.kr/feeds/verticals/korea/news.xml      
        
		
-------------------------------
        
		
# RSS 목록
        
무신사(MUSINSA) 기술블로그	https://medium.com/feed/musinsa-tech    
네이버 D2 기술블로그	https://d2.naver.com/d2.atom    
마켓컬리 기술블로그	https://helloworld.kurly.com/feed.xml      
우아한형제들 기술블로그	https://techblog.woowahan.com/feed    
카카오엔터프라이즈 기술블로그	https://tech.kakaoenterprise.com/feed    
데브시스터즈 기술블로그	https://tech.devsisters.com/rss.xml      
라인(LINE) 기술블로그	https://engineering.linecorp.com/ko/feed/index.html    
쿠팡(Coupang) 기술블로그	https://medium.com/feed/coupang-engineering    
당근마켓 기술블로그	https://medium.com/feed/daangn    
토스(Toss) 기술블로그	https://toss.tech/rss.xml      
직방 기술블로그	https://medium.com/feed/zigbang    
왓챠(Watcha) 기술블로그	https://medium.com/feed/watcha    
뱅크샐러드(banksalad) 기술블로그	https://blog.banksalad.com/rss.xml       
Hyperconnect 기술블로그	https://hyperconnect.github.io/feed.xml      
요기요(yogiyo) 기술블로그	https://techblog.yogiyo.co.kr/feed    
쏘카(Socar) 기술블로그	https://tech.socarcorp.kr/feed    
리디(RIDI) 기술블로그	https://www.ridicorp.com/feed    
NHN Toast 기술블로그	https://meetup.toast.com/rss    
GeekNews - 개발/기술/스타트업 뉴스 서비스	https://news.hada.io/rss/news    
개발자 블로그 서비스 - Velog	https://v2.velog.io/rss/    
월간 개발자 뉴스레터 - 개발자스럽다	https://blog.gaerae.com/feeds/posts/default?alt=rss    
IT 관련 뉴스 제공 블로그 - 44BITS	https://www.44bits.io/ko/feed/all    
        
		
		
		
## tech		
		
tech crunch  https://techcrunch.com/feed    
hacker news  https://news.ycombinator.com/rss    
verge  https://www.theverge.com/rss/full.xml      
venture beat  https://venturebeat.com/feed/    
		
		
		
		
## AI		
		
medium의 ai 태그  https://medium.com/feed/tag/artificial-intelligence    
techcrunch ai tag  https://techcrunch.com/tag/artificial-intelligence/feed/    
reddit artificial 서브레딧  https://www.reddit.com/r/artificial/.rss    
flipboard ai 분야  https://flipboard.com/topic/artificialintelligence.rss    
구글 블로그 ai 분야  https://blog.google/technology/ai/rss/    
deepmind  https://www.deepmind.com/blog/rss.xml      
the decoder  https://the-decoder.com/feed/    
      
AI Times (에이아이타임즈) https://www.aitimes.com/rss/allArticle.xml
The Batch (by DeepLearning.AI) https://www.deeplearning.ai/the-batch/feed/
MIT Tech Review – AI https://www.technologyreview.com/feed/
		
		
		
		
## 한국		
    
[새 탭에서 열기](https://www.google.com/){:target="_blank"}    
	
[테크니들](https://techneedle.com/){:target="_blank"}      
    
테크니들  (https://techneedle.com/feed)		
		
		
		
