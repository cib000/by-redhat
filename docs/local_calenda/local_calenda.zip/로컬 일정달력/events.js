const scheduleData = {
    "schedules": [
        {
            "id": "1",
            "date": "2026-01-01",
            "title": "이달을 정리해보기",
            "type": "메모",
            "repeat": "없음"
        },
        {
            "id": "2",
            "date": "2026-08-25",
            "title": "공과 세금 정산일",
            "type": "공과금",
            "repeat": "매월"
        },
        {
            "id": "3",
            "date": "2026-08-18",
            "title": "설사기 나무님 방문",
            "type": "메모",
            "repeat": "없음"
        },
        {
            "id": "4",
            "date": "2026-08-27",
            "title": "초당 결근 - 병원",
            "type": "메모",
            "repeat": "없음"
        },
        {
            "id": "5",
            "date": "2026-08-28",
            "title": "초당 결근",
            "type": "메모",
            "repeat": "없음"
        },
        {
            "id": "6",
            "date": "2026-08-28",
            "title": "메인보드님 의뢰 - 테스트",
            "type": "메모",
            "repeat": "없음"
        }
    ]
};