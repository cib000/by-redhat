const textarea = document.getElementById('code');
const iframe = document.getElementById('preview');

function updatePreview() {
  const raw = textarea.value.replace(/\r\n/g, "\n");
  const html = marked.parse(raw);
  marked.setOptions({
    breaks: true,
    gfm: true,
    highlight: (code, lang) => {
      const validLang = hljs.getLanguage(lang) ? lang : 'plaintext';
      return hljs.highlight(code, { language: validLang }).value;
    },
    langPrefix: 'hljs language-',
  });

  iframe.srcdoc = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/github-markdown-css/5.2.0/github-markdown.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/styles/github.min.css">
      <style>
        body {
          background: #0d1117;
          color: #c9d1d9;
          padding: 2rem;
          font-family: sans-serif;
        }
        pre code {
          border-radius: 6px;
        }
      </style>
    </head>
    <body class="markdown-body">
      ${html}
      <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.7.0/highlight.min.js"><\/script>
      <script>hljs.highlightAll();<\/script>
    </body>
    </html>
  `;
}

textarea.addEventListener('input', updatePreview);
window.addEventListener('DOMContentLoaded', updatePreview);
