# Report Up (Markdown Paginator)

A Pen created on CodePen.

Original URL: [https://codepen.io/tonywhite1985/pen/wvZjRZJ](https://codepen.io/tonywhite1985/pen/wvZjRZJ).

I'm looking for a Markdown editor that can print to PDF with my CSS and my color palette.
It can print presentable text for technical documentation.
It has some important features (for me) to format page and text.
It must have few dependencies, then can be installed easily with copy-paste, without frameworks or other amenities.